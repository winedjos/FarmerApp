self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "226859d39f689fa57becce55091272dd",
    "url": "/index.html"
  },
  {
    "revision": "d13a3824cd6897b67045",
    "url": "/static/css/10.0e4500f5.chunk.css"
  },
  {
    "revision": "51b2506b0c78a99776a8",
    "url": "/static/css/main.c5a46643.chunk.css"
  },
  {
    "revision": "2f585fa453768d7fc348",
    "url": "/static/js/0.6edce716.chunk.js"
  },
  {
    "revision": "d8c2046ea8e8ba1f898e",
    "url": "/static/js/1.67c5b627.chunk.js"
  },
  {
    "revision": "d13a3824cd6897b67045",
    "url": "/static/js/10.17e3a081.chunk.js"
  },
  {
    "revision": "006d04a9b6c320ea4a19817583fd5bd3",
    "url": "/static/js/10.17e3a081.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3ddf01ef44b639e8b1a4",
    "url": "/static/js/11.06109174.chunk.js"
  },
  {
    "revision": "761007e3cb5043b14e7c",
    "url": "/static/js/12.5ecb9d1f.chunk.js"
  },
  {
    "revision": "2f88ccad91cbea17922d",
    "url": "/static/js/13.f756d6f3.chunk.js"
  },
  {
    "revision": "10af602cc5a657dc2bab",
    "url": "/static/js/14.52392e53.chunk.js"
  },
  {
    "revision": "88b8e22cad6653d278cb",
    "url": "/static/js/15.70f22e21.chunk.js"
  },
  {
    "revision": "45195925391aea8667f5",
    "url": "/static/js/16.1ab137dc.chunk.js"
  },
  {
    "revision": "32fbf82b6dfcdb4c03dd",
    "url": "/static/js/17.22742aad.chunk.js"
  },
  {
    "revision": "c9448e64643d4ea49d19",
    "url": "/static/js/18.24383f54.chunk.js"
  },
  {
    "revision": "39fbad9cf5eb432d2510",
    "url": "/static/js/19.8dd01b25.chunk.js"
  },
  {
    "revision": "06ac03612ecfb133e301",
    "url": "/static/js/2.55612e98.chunk.js"
  },
  {
    "revision": "1f108a943ef3e43d655a",
    "url": "/static/js/20.ac45ea63.chunk.js"
  },
  {
    "revision": "f5e7863947d6ba47ef8c",
    "url": "/static/js/21.4010b16a.chunk.js"
  },
  {
    "revision": "9490ceb4c5cc59bd8481",
    "url": "/static/js/22.0af68105.chunk.js"
  },
  {
    "revision": "a7d22c1e7fcc995e110d",
    "url": "/static/js/23.df9e65d7.chunk.js"
  },
  {
    "revision": "812873fa4e4177f698a1",
    "url": "/static/js/24.9361e21f.chunk.js"
  },
  {
    "revision": "0ee7fac864da030ea34b",
    "url": "/static/js/25.e934476c.chunk.js"
  },
  {
    "revision": "ba31ecd8682f1798d20a",
    "url": "/static/js/26.e4cb25a3.chunk.js"
  },
  {
    "revision": "6fac63771015215d8d73",
    "url": "/static/js/27.da5eeb21.chunk.js"
  },
  {
    "revision": "a72017655a07cb0cc405",
    "url": "/static/js/28.21e09a8a.chunk.js"
  },
  {
    "revision": "d56a402d912c368debab",
    "url": "/static/js/29.632dde01.chunk.js"
  },
  {
    "revision": "46cca35d8b5a2ace4fcd",
    "url": "/static/js/3.e42fc311.chunk.js"
  },
  {
    "revision": "7c9bc6ec4991d16b0f2c",
    "url": "/static/js/30.8bd25d94.chunk.js"
  },
  {
    "revision": "47accbd182219ba4be32",
    "url": "/static/js/31.e4f1d469.chunk.js"
  },
  {
    "revision": "875b33c09e789c7f7d34",
    "url": "/static/js/32.0ef6afd9.chunk.js"
  },
  {
    "revision": "76e3520ef4f09ee4d9fd",
    "url": "/static/js/33.7a0e68d4.chunk.js"
  },
  {
    "revision": "5671a15189330baa9b3f",
    "url": "/static/js/34.70fef4e2.chunk.js"
  },
  {
    "revision": "c0d3b4c033b52d8a2d30",
    "url": "/static/js/35.f605f980.chunk.js"
  },
  {
    "revision": "18ac0f7513b5f50e8a65",
    "url": "/static/js/36.d394b968.chunk.js"
  },
  {
    "revision": "909354860669ca2b9fbb",
    "url": "/static/js/37.c276e6ed.chunk.js"
  },
  {
    "revision": "082676db82f66d2aa776",
    "url": "/static/js/38.8a97d425.chunk.js"
  },
  {
    "revision": "2620cd3c2d8ff0eec701",
    "url": "/static/js/39.b2e67116.chunk.js"
  },
  {
    "revision": "964d0653b41187c0ece8",
    "url": "/static/js/4.872ff840.chunk.js"
  },
  {
    "revision": "66a3109dace259fcbbe9",
    "url": "/static/js/40.16e51028.chunk.js"
  },
  {
    "revision": "eeb10f147f4f8df0f329",
    "url": "/static/js/41.088cf64d.chunk.js"
  },
  {
    "revision": "da0806fa3aa622cef3b6",
    "url": "/static/js/42.5bcfa613.chunk.js"
  },
  {
    "revision": "34dc276d3b895534fbff",
    "url": "/static/js/43.85e90571.chunk.js"
  },
  {
    "revision": "534f1a1936ce53719463",
    "url": "/static/js/44.b52b48c4.chunk.js"
  },
  {
    "revision": "0d256a8f2a8fe89728ce",
    "url": "/static/js/45.830e5254.chunk.js"
  },
  {
    "revision": "2d12e83abb664d94e079",
    "url": "/static/js/46.4590dc2b.chunk.js"
  },
  {
    "revision": "fe2dad0f6c7e985de486",
    "url": "/static/js/47.65f65f9d.chunk.js"
  },
  {
    "revision": "d214f158784025e5b7ec",
    "url": "/static/js/48.049ea713.chunk.js"
  },
  {
    "revision": "a79266cdb38b6b1253c7",
    "url": "/static/js/49.37690f91.chunk.js"
  },
  {
    "revision": "023f784ffa2baf20e203",
    "url": "/static/js/5.ee052dca.chunk.js"
  },
  {
    "revision": "94a17ef7d1c039d9a16c",
    "url": "/static/js/50.a8f4a150.chunk.js"
  },
  {
    "revision": "b2e71edfcfa5a91434ef",
    "url": "/static/js/51.6f57899f.chunk.js"
  },
  {
    "revision": "fdc9b31c1f0ea1f0892a",
    "url": "/static/js/52.720e6f7f.chunk.js"
  },
  {
    "revision": "42baff803d7e95cdeeb1",
    "url": "/static/js/53.8057c3ea.chunk.js"
  },
  {
    "revision": "7025c049f9df04f0cb9d",
    "url": "/static/js/54.815e0673.chunk.js"
  },
  {
    "revision": "78207031c0a8319efe33",
    "url": "/static/js/55.d19a3f7f.chunk.js"
  },
  {
    "revision": "5c83b0b56d993ff6bf84",
    "url": "/static/js/56.d34a7277.chunk.js"
  },
  {
    "revision": "2b33c69c9cfa65a34646",
    "url": "/static/js/57.03c79b3c.chunk.js"
  },
  {
    "revision": "942c0b7e56b318478aef",
    "url": "/static/js/58.a7dcfb25.chunk.js"
  },
  {
    "revision": "3cff95a46860bf248d93",
    "url": "/static/js/59.84280d95.chunk.js"
  },
  {
    "revision": "20701cec24596a726626",
    "url": "/static/js/6.844d6180.chunk.js"
  },
  {
    "revision": "38545f51d81b32a4a534",
    "url": "/static/js/60.14138b44.chunk.js"
  },
  {
    "revision": "17f3fa9580f04d38d041",
    "url": "/static/js/61.33477b0c.chunk.js"
  },
  {
    "revision": "4501fa6702de90c6abc2",
    "url": "/static/js/62.52235b99.chunk.js"
  },
  {
    "revision": "d9cfa675544f2f3b23df",
    "url": "/static/js/63.0a131369.chunk.js"
  },
  {
    "revision": "c2bbc84c2aec332b8573",
    "url": "/static/js/64.2ac4e208.chunk.js"
  },
  {
    "revision": "0551700be7ef38096f70",
    "url": "/static/js/65.b1e8dee4.chunk.js"
  },
  {
    "revision": "aecc325318fca7ccb1cd",
    "url": "/static/js/66.6594a931.chunk.js"
  },
  {
    "revision": "42b7d25728a15c4b2bef",
    "url": "/static/js/67.6760dd64.chunk.js"
  },
  {
    "revision": "a7b4174aa71077fe59a1",
    "url": "/static/js/68.126ad053.chunk.js"
  },
  {
    "revision": "6611f521145b285fef39",
    "url": "/static/js/69.7ee508ac.chunk.js"
  },
  {
    "revision": "92d5759fbdbdfc5fe81e",
    "url": "/static/js/7.979044b4.chunk.js"
  },
  {
    "revision": "a53a893a0b9b3756645c",
    "url": "/static/js/70.66e448d6.chunk.js"
  },
  {
    "revision": "41c6ac0bb781f194eec5",
    "url": "/static/js/71.52c3db73.chunk.js"
  },
  {
    "revision": "7a792ce3aed9d31dc1c6",
    "url": "/static/js/72.7becb5c6.chunk.js"
  },
  {
    "revision": "8002defdacdb08d2acf1",
    "url": "/static/js/73.007e513f.chunk.js"
  },
  {
    "revision": "47c17a241d1b9c6ecacc",
    "url": "/static/js/74.fc471727.chunk.js"
  },
  {
    "revision": "1db82da706dd580fec4f",
    "url": "/static/js/75.13d23a2f.chunk.js"
  },
  {
    "revision": "a5fa47f0b204c8f6c31b",
    "url": "/static/js/76.8bf93a70.chunk.js"
  },
  {
    "revision": "ddcaf625a6613a7a1b95",
    "url": "/static/js/77.a365dcda.chunk.js"
  },
  {
    "revision": "91b76fc6583349a701e1",
    "url": "/static/js/78.a6795eb4.chunk.js"
  },
  {
    "revision": "0e89020bb3078d833c78",
    "url": "/static/js/79.7c2beacf.chunk.js"
  },
  {
    "revision": "ecbc462186de00e8b13a",
    "url": "/static/js/80.be4b5619.chunk.js"
  },
  {
    "revision": "90b6b156a5f62810eddc9189ae0e43d4",
    "url": "/static/js/80.be4b5619.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ee4820009a602b89d2c3",
    "url": "/static/js/81.c8a7e00c.chunk.js"
  },
  {
    "revision": "93ee1876f5d2f69c0164",
    "url": "/static/js/82.f1e74257.chunk.js"
  },
  {
    "revision": "a62fe8f25c6e73799c38",
    "url": "/static/js/83.41558532.chunk.js"
  },
  {
    "revision": "c673487c0cc87f0cc941",
    "url": "/static/js/84.5d9c901a.chunk.js"
  },
  {
    "revision": "e1a791b75e82f6913738",
    "url": "/static/js/85.9b642902.chunk.js"
  },
  {
    "revision": "6db2de1ad26ed4a33531",
    "url": "/static/js/86.538d73d5.chunk.js"
  },
  {
    "revision": "aee79bf72f90b3b99dc1",
    "url": "/static/js/87.e7289c5b.chunk.js"
  },
  {
    "revision": "f881ba948f79019d4b2c",
    "url": "/static/js/88.1051ea5c.chunk.js"
  },
  {
    "revision": "644cc09059fa356386f5",
    "url": "/static/js/89.c96b30c9.chunk.js"
  },
  {
    "revision": "b883c7e4aeb37cb5fc19",
    "url": "/static/js/90.b11331af.chunk.js"
  },
  {
    "revision": "ae71e91ba342eb971ef3",
    "url": "/static/js/91.4a8aefac.chunk.js"
  },
  {
    "revision": "ed458243183500066ef8",
    "url": "/static/js/92.8ccdf233.chunk.js"
  },
  {
    "revision": "5371edd43b9691c29125",
    "url": "/static/js/93.3b1e5665.chunk.js"
  },
  {
    "revision": "383899e60ed69a9a53414c6836d91ab5",
    "url": "/static/js/93.3b1e5665.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a0ed66e08e3523eef46e",
    "url": "/static/js/94.a5521432.chunk.js"
  },
  {
    "revision": "3fed3944298836c765fa",
    "url": "/static/js/95.a4ddd843.chunk.js"
  },
  {
    "revision": "90b6b156a5f62810eddc9189ae0e43d4",
    "url": "/static/js/95.a4ddd843.chunk.js.LICENSE.txt"
  },
  {
    "revision": "55495ace216aedd73e04",
    "url": "/static/js/96.1f06a42a.chunk.js"
  },
  {
    "revision": "2aac3014e5220274f5b0",
    "url": "/static/js/97.fbb620a4.chunk.js"
  },
  {
    "revision": "d74069c52b0a560654d7acf5aae4dab5",
    "url": "/static/js/97.fbb620a4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "583ae5cc1a4d1b8109a7",
    "url": "/static/js/98.a31d9c0b.chunk.js"
  },
  {
    "revision": "f4f883e1e471dd72bcd3",
    "url": "/static/js/99.c395a005.chunk.js"
  },
  {
    "revision": "383899e60ed69a9a53414c6836d91ab5",
    "url": "/static/js/99.c395a005.chunk.js.LICENSE.txt"
  },
  {
    "revision": "51b2506b0c78a99776a8",
    "url": "/static/js/main.81f42c40.chunk.js"
  },
  {
    "revision": "9759e7737e897ce17c6f",
    "url": "/static/js/runtime-main.c8b1b5aa.js"
  },
  {
    "revision": "a07084fde4c49d88a936090acae1a4c5",
    "url": "/static/media/bg.a07084fd.jpg"
  },
  {
    "revision": "e3a9f2f687b3ee74d58820b793f2b248",
    "url": "/static/media/ios-add-circle-outline.e3a9f2f6.svg"
  },
  {
    "revision": "25f2a81bd919d127dadd08f5196664b5",
    "url": "/static/media/ios-add-circle.25f2a81b.svg"
  },
  {
    "revision": "2cb95301c44b09941b851104b6580829",
    "url": "/static/media/ios-add.2cb95301.svg"
  },
  {
    "revision": "55a73c2b79459e5406516b3250dc6b5b",
    "url": "/static/media/ios-airplane.55a73c2b.svg"
  },
  {
    "revision": "e66a15bbeef9289982475419cfc1e72f",
    "url": "/static/media/ios-alarm.e66a15bb.svg"
  },
  {
    "revision": "a374f8b0f4fc369f6d6de9df29ac66a1",
    "url": "/static/media/ios-albums.a374f8b0.svg"
  },
  {
    "revision": "80af9b4a632a8f6dbd5d107a2dfb52b8",
    "url": "/static/media/ios-alert.80af9b4a.svg"
  },
  {
    "revision": "f5ad3ee86c68ef271248a066ebd36ff7",
    "url": "/static/media/ios-american-football.f5ad3ee8.svg"
  },
  {
    "revision": "4d4bb303d1fc1f4f64167a7fc962d837",
    "url": "/static/media/ios-analytics.4d4bb303.svg"
  },
  {
    "revision": "f7015431f586cd38d97eb0a6485a591a",
    "url": "/static/media/ios-aperture.f7015431.svg"
  },
  {
    "revision": "77b5497cc2cf2b63cced36d7850515fc",
    "url": "/static/media/ios-apps.77b5497c.svg"
  },
  {
    "revision": "426f0862712673012efdf90748351737",
    "url": "/static/media/ios-appstore.426f0862.svg"
  },
  {
    "revision": "ec93fa373cc8cd538b0f026b5433a958",
    "url": "/static/media/ios-archive.ec93fa37.svg"
  },
  {
    "revision": "870690d288f124530703b21807a410c7",
    "url": "/static/media/ios-arrow-back.870690d2.svg"
  },
  {
    "revision": "7263e94fedf8e3642f9a71ffce663f0d",
    "url": "/static/media/ios-arrow-down.7263e94f.svg"
  },
  {
    "revision": "ac67ab6d18b3f09b963f54d6cd3533af",
    "url": "/static/media/ios-arrow-dropdown-circle.ac67ab6d.svg"
  },
  {
    "revision": "ddbb8461ecca7285874abcde06360ed7",
    "url": "/static/media/ios-arrow-dropdown.ddbb8461.svg"
  },
  {
    "revision": "440c0e1b75d6f3ff2b37a980208ae7f0",
    "url": "/static/media/ios-arrow-dropleft-circle.440c0e1b.svg"
  },
  {
    "revision": "ebff291c0593ed2ee82716367feab22f",
    "url": "/static/media/ios-arrow-dropleft.ebff291c.svg"
  },
  {
    "revision": "f740cc88e47e2e4202cea1352d0faedb",
    "url": "/static/media/ios-arrow-dropright-circle.f740cc88.svg"
  },
  {
    "revision": "608198260afefb39e2ab329c35e595c0",
    "url": "/static/media/ios-arrow-dropright.60819826.svg"
  },
  {
    "revision": "38670abdcad0294495bb19c9917eee83",
    "url": "/static/media/ios-arrow-dropup-circle.38670abd.svg"
  },
  {
    "revision": "80a7e2b16266329e1353f4959cdbcb38",
    "url": "/static/media/ios-arrow-dropup.80a7e2b1.svg"
  },
  {
    "revision": "34ad64270469944a598e719cf9c29444",
    "url": "/static/media/ios-arrow-forward.34ad6427.svg"
  },
  {
    "revision": "c3a732cdaf5b404041e05cefe032ae44",
    "url": "/static/media/ios-arrow-round-back.c3a732cd.svg"
  },
  {
    "revision": "3ceed256e24e53bbe70a9ce62af98ffe",
    "url": "/static/media/ios-arrow-round-down.3ceed256.svg"
  },
  {
    "revision": "c6315be08b7eccc6ddc1209da84ecdd8",
    "url": "/static/media/ios-arrow-round-forward.c6315be0.svg"
  },
  {
    "revision": "14aa8e971cdcb34bed3bc3dbebcac729",
    "url": "/static/media/ios-arrow-round-up.14aa8e97.svg"
  },
  {
    "revision": "7a0ca93229745aac41173dc5cf2d22a6",
    "url": "/static/media/ios-arrow-up.7a0ca932.svg"
  },
  {
    "revision": "f5b9c225e4b22ef63ea0b6d140f19ec8",
    "url": "/static/media/ios-at.f5b9c225.svg"
  },
  {
    "revision": "fe71219f9af133a03bbaf945e7f722d0",
    "url": "/static/media/ios-attach.fe71219f.svg"
  },
  {
    "revision": "3e8ce21a36203acb6e83deb5ce02092b",
    "url": "/static/media/ios-backspace.3e8ce21a.svg"
  },
  {
    "revision": "29f38fb61ee2d03d2b079ddac6dec825",
    "url": "/static/media/ios-barcode.29f38fb6.svg"
  },
  {
    "revision": "484cd4bdcd2d6a5309708e89964380ac",
    "url": "/static/media/ios-baseball.484cd4bd.svg"
  },
  {
    "revision": "d341ba6c5dbaf3266253445b0689000e",
    "url": "/static/media/ios-basket.d341ba6c.svg"
  },
  {
    "revision": "30ac26ed4f3941cd0a0fc48888e7d65e",
    "url": "/static/media/ios-basketball.30ac26ed.svg"
  },
  {
    "revision": "2608b14850b2d03b274149f7e7e294f0",
    "url": "/static/media/ios-battery-charging.2608b148.svg"
  },
  {
    "revision": "4bfec6a457aae08903af11db68088b1a",
    "url": "/static/media/ios-battery-dead.4bfec6a4.svg"
  },
  {
    "revision": "992ccb8eadc75194b7eb1702e5c80afc",
    "url": "/static/media/ios-battery-full.992ccb8e.svg"
  },
  {
    "revision": "00f085e7f4bea9344217385a115f635d",
    "url": "/static/media/ios-beaker.00f085e7.svg"
  },
  {
    "revision": "edf7025d14316df2c669a49449abd7dd",
    "url": "/static/media/ios-bed.edf7025d.svg"
  },
  {
    "revision": "0e9275f4a73ff626d7f197abd12d00ce",
    "url": "/static/media/ios-beer.0e9275f4.svg"
  },
  {
    "revision": "edfaa92fd059e74ba4aba5df359df44d",
    "url": "/static/media/ios-bicycle.edfaa92f.svg"
  },
  {
    "revision": "b913deea9a87e0c79c17f28ffc7fb325",
    "url": "/static/media/ios-bluetooth.b913deea.svg"
  },
  {
    "revision": "e08fdee3a6ba21053b97e8d3ea97a1cb",
    "url": "/static/media/ios-boat.e08fdee3.svg"
  },
  {
    "revision": "6308adf47185f99ef2b3b021c8d34033",
    "url": "/static/media/ios-body.6308adf4.svg"
  },
  {
    "revision": "edb56a186d476ec547a77dd96864191a",
    "url": "/static/media/ios-bonfire.edb56a18.svg"
  },
  {
    "revision": "996d8c7d69414050f815174ca8b8892e",
    "url": "/static/media/ios-book.996d8c7d.svg"
  },
  {
    "revision": "c39612e8d5149892135a98c6aa16c754",
    "url": "/static/media/ios-bookmark.c39612e8.svg"
  },
  {
    "revision": "aef6abbae8f00ce51fec93c33f5d8582",
    "url": "/static/media/ios-bookmarks.aef6abba.svg"
  },
  {
    "revision": "6bf750bba04a9aec7f9f731ad67e247f",
    "url": "/static/media/ios-bowtie.6bf750bb.svg"
  },
  {
    "revision": "67a166ffd1b22d3b8b1a07f42ebc666d",
    "url": "/static/media/ios-briefcase.67a166ff.svg"
  },
  {
    "revision": "691f0713c741d37f85cd752691a69738",
    "url": "/static/media/ios-browsers.691f0713.svg"
  },
  {
    "revision": "61f0abe937e6bed8dea8dbb45f5ef764",
    "url": "/static/media/ios-brush.61f0abe9.svg"
  },
  {
    "revision": "38751a5f77542d48e9ad1a3a5502a960",
    "url": "/static/media/ios-bug.38751a5f.svg"
  },
  {
    "revision": "767c1fd0a7bfb7b723e95fd0455bb4e5",
    "url": "/static/media/ios-build.767c1fd0.svg"
  },
  {
    "revision": "7a7f90f37f0fc2a35e83fc8af7144c2e",
    "url": "/static/media/ios-bulb.7a7f90f3.svg"
  },
  {
    "revision": "f1624a25fb61af998a851f40a8c3ebd8",
    "url": "/static/media/ios-bus.f1624a25.svg"
  },
  {
    "revision": "c04e5b35f1c123be7e187983c206dc42",
    "url": "/static/media/ios-business.c04e5b35.svg"
  },
  {
    "revision": "89e900312ec68dfb3ec538f03559f59f",
    "url": "/static/media/ios-cafe.89e90031.svg"
  },
  {
    "revision": "d02588d1c48c7f82fffa916273cbe431",
    "url": "/static/media/ios-calculator.d02588d1.svg"
  },
  {
    "revision": "5453e7066da50d4d3291442ec0ff9fc4",
    "url": "/static/media/ios-calendar.5453e706.svg"
  },
  {
    "revision": "58e002ddaa03e0e330c76ba6ccaa8035",
    "url": "/static/media/ios-call.58e002dd.svg"
  },
  {
    "revision": "ca4e94fa493fc9bce6141b9d95f79f98",
    "url": "/static/media/ios-camera.ca4e94fa.svg"
  },
  {
    "revision": "84545fddfebf8149fe1e9ce2a40f421b",
    "url": "/static/media/ios-car.84545fdd.svg"
  },
  {
    "revision": "e6ed23260ef975c46fd8eeeae0b1b071",
    "url": "/static/media/ios-card.e6ed2326.svg"
  },
  {
    "revision": "b4a30bdded68c3915952977cb25fdf06",
    "url": "/static/media/ios-cart.b4a30bdd.svg"
  },
  {
    "revision": "2d670abce1e5f389614de7b42af3c990",
    "url": "/static/media/ios-cash.2d670abc.svg"
  },
  {
    "revision": "241c6df6d21822801ca7949442bd7df4",
    "url": "/static/media/ios-cellular.241c6df6.svg"
  },
  {
    "revision": "e286abea9af29bce430ca129a8a8a0b0",
    "url": "/static/media/ios-chatboxes.e286abea.svg"
  },
  {
    "revision": "67cc3b7e735a16d80b0a64529c3b3887",
    "url": "/static/media/ios-chatbubbles.67cc3b7e.svg"
  },
  {
    "revision": "dc2e64eec181b3dd772049caca6ed071",
    "url": "/static/media/ios-checkbox-outline.dc2e64ee.svg"
  },
  {
    "revision": "7bb4da9dd7bab3b086d80fe01de2dffa",
    "url": "/static/media/ios-checkbox.7bb4da9d.svg"
  },
  {
    "revision": "c4d4981ca99fcfaaa1b0e8ecd6d4e83a",
    "url": "/static/media/ios-checkmark-circle-outline.c4d4981c.svg"
  },
  {
    "revision": "2199536be881d80f69886059151d3c73",
    "url": "/static/media/ios-checkmark-circle.2199536b.svg"
  },
  {
    "revision": "a9500f2ca652ced3383fdcd7d43244ab",
    "url": "/static/media/ios-checkmark.a9500f2c.svg"
  },
  {
    "revision": "db2fd514100497a367f9b0257c28771b",
    "url": "/static/media/ios-clipboard.db2fd514.svg"
  },
  {
    "revision": "eefa347bc85e0d3c2b2f0db0567fe21b",
    "url": "/static/media/ios-clock.eefa347b.svg"
  },
  {
    "revision": "3dcea32cc7e335367524a0dc49dba8aa",
    "url": "/static/media/ios-close-circle-outline.3dcea32c.svg"
  },
  {
    "revision": "045d23e14a91e538885b19af70d31366",
    "url": "/static/media/ios-close-circle.045d23e1.svg"
  },
  {
    "revision": "91fc43e19f3729d4fefaec1e24cd11e1",
    "url": "/static/media/ios-close.91fc43e1.svg"
  },
  {
    "revision": "016143622a291772fc3ded324eb03185",
    "url": "/static/media/ios-cloud-circle.01614362.svg"
  },
  {
    "revision": "7c0ec8d8a1ab067e2825002664133965",
    "url": "/static/media/ios-cloud-done.7c0ec8d8.svg"
  },
  {
    "revision": "11442ba2b348e60bc193d04a39f61a18",
    "url": "/static/media/ios-cloud-download.11442ba2.svg"
  },
  {
    "revision": "28bee076ebe5d51d1066ee3bb09492bf",
    "url": "/static/media/ios-cloud-outline.28bee076.svg"
  },
  {
    "revision": "fea5c37a5d62b392e0b15a2cc1acfe5a",
    "url": "/static/media/ios-cloud-upload.fea5c37a.svg"
  },
  {
    "revision": "2de53d7bff2bc45fdd4b860e76f74068",
    "url": "/static/media/ios-cloud.2de53d7b.svg"
  },
  {
    "revision": "648e87f9efc874219766d06817247de9",
    "url": "/static/media/ios-cloudy-night.648e87f9.svg"
  },
  {
    "revision": "f7bf5d2a2d25d025f76a35dfa9c917d3",
    "url": "/static/media/ios-cloudy.f7bf5d2a.svg"
  },
  {
    "revision": "df5d303ee4f6f94712924124ab540456",
    "url": "/static/media/ios-code-download.df5d303e.svg"
  },
  {
    "revision": "c84611ad2e04ceed66e6d506c2fb3029",
    "url": "/static/media/ios-code-working.c84611ad.svg"
  },
  {
    "revision": "f922b4df493c34777a9f203067dde6dc",
    "url": "/static/media/ios-code.f922b4df.svg"
  },
  {
    "revision": "1886c06e66fdf4768e7ec8fa6e08c2a0",
    "url": "/static/media/ios-cog.1886c06e.svg"
  },
  {
    "revision": "c4c0a7a51df424b11610e5a0bb528883",
    "url": "/static/media/ios-color-fill.c4c0a7a5.svg"
  },
  {
    "revision": "804813949c5dc6c871a029dc6b46c1b8",
    "url": "/static/media/ios-color-filter.80481394.svg"
  },
  {
    "revision": "b2ce1b899f4682082e1bdad5733e9834",
    "url": "/static/media/ios-color-palette.b2ce1b89.svg"
  },
  {
    "revision": "af5b964f055fec21d5512ebcc8be08c4",
    "url": "/static/media/ios-color-wand.af5b964f.svg"
  },
  {
    "revision": "f82439ac95391220a602fc5c8ac45eed",
    "url": "/static/media/ios-compass.f82439ac.svg"
  },
  {
    "revision": "359788e8a850892bb91a4620f5cb5f0a",
    "url": "/static/media/ios-construct.359788e8.svg"
  },
  {
    "revision": "880cdcac37b032258e5415ca1311db7c",
    "url": "/static/media/ios-contact.880cdcac.svg"
  },
  {
    "revision": "7a65f865cac99887b73a93586780bb74",
    "url": "/static/media/ios-contacts.7a65f865.svg"
  },
  {
    "revision": "a838f7828e43f86ae817df5eb9abdf40",
    "url": "/static/media/ios-contract.a838f782.svg"
  },
  {
    "revision": "1b6f1155eb6d8871d0ed8b7e8a66c908",
    "url": "/static/media/ios-contrast.1b6f1155.svg"
  },
  {
    "revision": "2a4db2cb58630272a434a0143b90956b",
    "url": "/static/media/ios-copy.2a4db2cb.svg"
  },
  {
    "revision": "5290b1ac22320048a2af016d012cc492",
    "url": "/static/media/ios-create.5290b1ac.svg"
  },
  {
    "revision": "56ec7f79dd15fe41f66420cb0f30ddf3",
    "url": "/static/media/ios-crop.56ec7f79.svg"
  },
  {
    "revision": "060b2c3510cda3f1a369739b3bf20cdb",
    "url": "/static/media/ios-cube.060b2c35.svg"
  },
  {
    "revision": "400954d3123a284809aa9558ee535df8",
    "url": "/static/media/ios-cut.400954d3.svg"
  },
  {
    "revision": "0f4315521ee15af6b63c0a516cb51438",
    "url": "/static/media/ios-desktop.0f431552.svg"
  },
  {
    "revision": "870f2dd8f8083ad09d8a76d5b9d0117e",
    "url": "/static/media/ios-disc.870f2dd8.svg"
  },
  {
    "revision": "a692c4910eccf2f3c8690884a777b3c0",
    "url": "/static/media/ios-document.a692c491.svg"
  },
  {
    "revision": "bd421527dcd18dbabc386afe9cde389e",
    "url": "/static/media/ios-done-all.bd421527.svg"
  },
  {
    "revision": "617c2bba050589c743570ccbce5b0b6e",
    "url": "/static/media/ios-download.617c2bba.svg"
  },
  {
    "revision": "d56d335ba6078c385d9217d5e543b6c6",
    "url": "/static/media/ios-easel.d56d335b.svg"
  },
  {
    "revision": "61371e93125d20a17d47e51bc1a37efb",
    "url": "/static/media/ios-egg.61371e93.svg"
  },
  {
    "revision": "9571a4395f3de87305d4b40be3e1096c",
    "url": "/static/media/ios-exit.9571a439.svg"
  },
  {
    "revision": "8d6acbb6beeab5e370d82b32b749e1d5",
    "url": "/static/media/ios-expand.8d6acbb6.svg"
  },
  {
    "revision": "6de634b234457695291ee722742dd24d",
    "url": "/static/media/ios-eye-off.6de634b2.svg"
  },
  {
    "revision": "540ca603a758367b97cd7c2d97fca880",
    "url": "/static/media/ios-eye.540ca603.svg"
  },
  {
    "revision": "1be797490eb054fed3f5b169b6fa60ff",
    "url": "/static/media/ios-fastforward.1be79749.svg"
  },
  {
    "revision": "0331d98221eff8def990e7b87849d813",
    "url": "/static/media/ios-female.0331d982.svg"
  },
  {
    "revision": "a7d2de58fb1987e92da8d38b1a860fb0",
    "url": "/static/media/ios-filing.a7d2de58.svg"
  },
  {
    "revision": "ca296b3b778bc72884fb9c6e4e50d5ed",
    "url": "/static/media/ios-film.ca296b3b.svg"
  },
  {
    "revision": "82accc8a43e862330869f8a3deeb58d4",
    "url": "/static/media/ios-finger-print.82accc8a.svg"
  },
  {
    "revision": "d7cce0c4a9b2463004c3cff26db616af",
    "url": "/static/media/ios-fitness.d7cce0c4.svg"
  },
  {
    "revision": "5b62c93f19692d0ef6ce1c1d1638e935",
    "url": "/static/media/ios-flag.5b62c93f.svg"
  },
  {
    "revision": "254d0694817e4f085f70b0d95dead329",
    "url": "/static/media/ios-flame.254d0694.svg"
  },
  {
    "revision": "d6a9695fec310d43943368b1ef5e2475",
    "url": "/static/media/ios-flash-off.d6a9695f.svg"
  },
  {
    "revision": "ee8ef10f255a4428de9de8ecfacc1187",
    "url": "/static/media/ios-flash.ee8ef10f.svg"
  },
  {
    "revision": "198292ce69fbbae6962c10b35eaba949",
    "url": "/static/media/ios-flashlight.198292ce.svg"
  },
  {
    "revision": "1efc53c782eb310d23fcbd52ee79366e",
    "url": "/static/media/ios-flask.1efc53c7.svg"
  },
  {
    "revision": "396e6d6776144cb5db242c6cdeccec67",
    "url": "/static/media/ios-flower.396e6d67.svg"
  },
  {
    "revision": "8e9668408ec87cce5f443008970e198d",
    "url": "/static/media/ios-folder-open.8e966840.svg"
  },
  {
    "revision": "cccc139f2578b81d642cd84c9186710a",
    "url": "/static/media/ios-folder.cccc139f.svg"
  },
  {
    "revision": "4cd5e4ddacebdffbbb6a33f135e5eef6",
    "url": "/static/media/ios-football.4cd5e4dd.svg"
  },
  {
    "revision": "5ef19496afd525a39d392653c50e9497",
    "url": "/static/media/ios-funnel.5ef19496.svg"
  },
  {
    "revision": "e1918564c234b895170117a974975efb",
    "url": "/static/media/ios-gift.e1918564.svg"
  },
  {
    "revision": "96df9373cb658fa839bc6e6a82ad813f",
    "url": "/static/media/ios-git-branch.96df9373.svg"
  },
  {
    "revision": "8aabe86d2d687314bcd006eab38a84c9",
    "url": "/static/media/ios-git-commit.8aabe86d.svg"
  },
  {
    "revision": "92c4be0ab4095f31aaa9b5815b01864a",
    "url": "/static/media/ios-git-compare.92c4be0a.svg"
  },
  {
    "revision": "3686d876c2a898a61263c3c4258f2bed",
    "url": "/static/media/ios-git-merge.3686d876.svg"
  },
  {
    "revision": "01863984d00bb730d6e2ac33979a25f9",
    "url": "/static/media/ios-git-network.01863984.svg"
  },
  {
    "revision": "ba4f8467df7068b94f82299f513a1006",
    "url": "/static/media/ios-git-pull-request.ba4f8467.svg"
  },
  {
    "revision": "b3a62b49a7b482edc512f666a31534ac",
    "url": "/static/media/ios-glasses.b3a62b49.svg"
  },
  {
    "revision": "f74670c8f31f956b48ec63837ff019d4",
    "url": "/static/media/ios-globe.f74670c8.svg"
  },
  {
    "revision": "6361f0df06d7c8e1e1bd7a4c404b285f",
    "url": "/static/media/ios-grid.6361f0df.svg"
  },
  {
    "revision": "ebb39ea4f254307d1c3be843134af40f",
    "url": "/static/media/ios-hammer.ebb39ea4.svg"
  },
  {
    "revision": "a888e451f6756de0cd1a6d5dcbdd3549",
    "url": "/static/media/ios-hand.a888e451.svg"
  },
  {
    "revision": "1fb7ccc3185e3bac7c642640544f6889",
    "url": "/static/media/ios-happy.1fb7ccc3.svg"
  },
  {
    "revision": "9706bb0015f5e906fda942cefa8e5a04",
    "url": "/static/media/ios-headset.9706bb00.svg"
  },
  {
    "revision": "a335ca3d7ef0b56c0e4d77e50b7014a5",
    "url": "/static/media/ios-heart-dislike.a335ca3d.svg"
  },
  {
    "revision": "62676aa5f6a750eeb7823de630049571",
    "url": "/static/media/ios-heart-empty.62676aa5.svg"
  },
  {
    "revision": "3015bda7e3f518f7e5dd0790d0ba81a8",
    "url": "/static/media/ios-heart-half.3015bda7.svg"
  },
  {
    "revision": "70501ebb3200f5e0eaaa86e010500f69",
    "url": "/static/media/ios-heart.70501ebb.svg"
  },
  {
    "revision": "07ac058965f1f7a13797fd069d44788f",
    "url": "/static/media/ios-help-buoy.07ac0589.svg"
  },
  {
    "revision": "6524a35bb4e8628a4a2578d110dae24a",
    "url": "/static/media/ios-help-circle-outline.6524a35b.svg"
  },
  {
    "revision": "c7cd8d694764134c66c053e949504426",
    "url": "/static/media/ios-help-circle.c7cd8d69.svg"
  },
  {
    "revision": "711abf9692f10591e4eec305ebe073f2",
    "url": "/static/media/ios-help.711abf96.svg"
  },
  {
    "revision": "b3a937c989493f4d47e132b98969ed6d",
    "url": "/static/media/ios-home.b3a937c9.svg"
  },
  {
    "revision": "3f0df3393f0c104aa66ecc44296dc846",
    "url": "/static/media/ios-hourglass.3f0df339.svg"
  },
  {
    "revision": "e18555385531994a4417d3b02f41c04c",
    "url": "/static/media/ios-ice-cream.e1855538.svg"
  },
  {
    "revision": "c2d00837584cea9b339f58a804606a9d",
    "url": "/static/media/ios-image.c2d00837.svg"
  },
  {
    "revision": "d7f458e4000748b062989d24d6c6b8ab",
    "url": "/static/media/ios-images.d7f458e4.svg"
  },
  {
    "revision": "fe08e3ab4834437f6f37499997395b56",
    "url": "/static/media/ios-infinite.fe08e3ab.svg"
  },
  {
    "revision": "1060abc0b193d38ad3d7553db0ee228e",
    "url": "/static/media/ios-information-circle-outline.1060abc0.svg"
  },
  {
    "revision": "4792d284aec1baa9dab63f21e7d713d5",
    "url": "/static/media/ios-information-circle.4792d284.svg"
  },
  {
    "revision": "1acfdf215a9753b8dc948d476851f432",
    "url": "/static/media/ios-information.1acfdf21.svg"
  },
  {
    "revision": "930e88d847a6c33d0460e5605f06bb6a",
    "url": "/static/media/ios-jet.930e88d8.svg"
  },
  {
    "revision": "7f15ea7809159a06694887eece475f70",
    "url": "/static/media/ios-journal.7f15ea78.svg"
  },
  {
    "revision": "c460c5cdc6dd1c9c78cd8340bdb09abe",
    "url": "/static/media/ios-key.c460c5cd.svg"
  },
  {
    "revision": "eca7d6a6cd24be563029f87ea629ee9b",
    "url": "/static/media/ios-keypad.eca7d6a6.svg"
  },
  {
    "revision": "617fdd4a608df9a2e59854bb6e0f5850",
    "url": "/static/media/ios-laptop.617fdd4a.svg"
  },
  {
    "revision": "affb9606aab7c2224fed0bbb4b6757fe",
    "url": "/static/media/ios-leaf.affb9606.svg"
  },
  {
    "revision": "153963b91936a6d6963e38e767885d43",
    "url": "/static/media/ios-link.153963b9.svg"
  },
  {
    "revision": "a9797658cc193ec3c7b7386deca5d4a3",
    "url": "/static/media/ios-list-box.a9797658.svg"
  },
  {
    "revision": "d4d689ab41c4ccbd0ede829b4470288b",
    "url": "/static/media/ios-list.d4d689ab.svg"
  },
  {
    "revision": "e4e11721c6d3612acfa72bb591b60ce0",
    "url": "/static/media/ios-locate.e4e11721.svg"
  },
  {
    "revision": "00c8437a9bdc5c5af2fd2c745755d1be",
    "url": "/static/media/ios-lock.00c8437a.svg"
  },
  {
    "revision": "eed1898b119d8ad73d5a9c7dbfaf722a",
    "url": "/static/media/ios-log-in.eed1898b.svg"
  },
  {
    "revision": "64666e4031635f5d90b22172b98a62b5",
    "url": "/static/media/ios-log-out.64666e40.svg"
  },
  {
    "revision": "436eacf15a54837c3cdb59aab1086969",
    "url": "/static/media/ios-magnet.436eacf1.svg"
  },
  {
    "revision": "acd756e2406a0103cf74b7966ab0856a",
    "url": "/static/media/ios-mail-open.acd756e2.svg"
  },
  {
    "revision": "2175fd907ffde6ad67744cddf3b0510f",
    "url": "/static/media/ios-mail-unread.2175fd90.svg"
  },
  {
    "revision": "8de2881eddd3b0250dc6f52f57292eda",
    "url": "/static/media/ios-mail.8de2881e.svg"
  },
  {
    "revision": "d01fb1a138e9136e2285f4c3cff89ad0",
    "url": "/static/media/ios-male.d01fb1a1.svg"
  },
  {
    "revision": "512dd1d1cf66ddd2b7785ae2aa7c33cc",
    "url": "/static/media/ios-man.512dd1d1.svg"
  },
  {
    "revision": "3e4eccd03bdc3cec13b5a5c7226c5418",
    "url": "/static/media/ios-map.3e4eccd0.svg"
  },
  {
    "revision": "128a419a0f9987855547883193e884e7",
    "url": "/static/media/ios-medal.128a419a.svg"
  },
  {
    "revision": "7d04893551337eec513ec0e16fd0ed4c",
    "url": "/static/media/ios-medical.7d048935.svg"
  },
  {
    "revision": "4e900541f64a4db1e481902ce113bc9c",
    "url": "/static/media/ios-medkit.4e900541.svg"
  },
  {
    "revision": "8a24fce5b10b97cb0c080f49487eb6a1",
    "url": "/static/media/ios-megaphone.8a24fce5.svg"
  },
  {
    "revision": "da93b3c4b97a15f0de4fa5b5cecfad8e",
    "url": "/static/media/ios-menu.da93b3c4.svg"
  },
  {
    "revision": "18ecd755be2c5e11875c1fdbd76c600e",
    "url": "/static/media/ios-mic-off.18ecd755.svg"
  },
  {
    "revision": "afbb719ffdff4e9ae4cbdb747389155a",
    "url": "/static/media/ios-mic.afbb719f.svg"
  },
  {
    "revision": "39d8c810b260118c869668fa9221338e",
    "url": "/static/media/ios-microphone.39d8c810.svg"
  },
  {
    "revision": "da5273cb0e21fd2adec1734ef8b73238",
    "url": "/static/media/ios-moon.da5273cb.svg"
  },
  {
    "revision": "fe8044819fa0a4dfe024da7705cae1dd",
    "url": "/static/media/ios-more.fe804481.svg"
  },
  {
    "revision": "0241f01b324b5ed372bc0168604833de",
    "url": "/static/media/ios-move.0241f01b.svg"
  },
  {
    "revision": "505bf3a64c0ec38b77286c8432506175",
    "url": "/static/media/ios-musical-note.505bf3a6.svg"
  },
  {
    "revision": "9309b13aa76171edd3e75dc22a72b74d",
    "url": "/static/media/ios-musical-notes.9309b13a.svg"
  },
  {
    "revision": "f739c2712bdd35616b784bd4ef250c80",
    "url": "/static/media/ios-navigate.f739c271.svg"
  },
  {
    "revision": "6a06cfa6799112f3864388bed6f7c85e",
    "url": "/static/media/ios-notifications-off.6a06cfa6.svg"
  },
  {
    "revision": "535670f68a6813bb965d22e3ab936f44",
    "url": "/static/media/ios-notifications-outline.535670f6.svg"
  },
  {
    "revision": "c39ec1ccd4de400f96ff404eabba49f2",
    "url": "/static/media/ios-notifications.c39ec1cc.svg"
  },
  {
    "revision": "3e069dd3b4cd1a9826a68215f7f9899e",
    "url": "/static/media/ios-nuclear.3e069dd3.svg"
  },
  {
    "revision": "7fb8777da45d1c76945c0c80ce4b4664",
    "url": "/static/media/ios-nutrition.7fb8777d.svg"
  },
  {
    "revision": "2560c62b484e23bd0ee85872d1f828ed",
    "url": "/static/media/ios-open.2560c62b.svg"
  },
  {
    "revision": "21a6d93ee77721406cd219e492992127",
    "url": "/static/media/ios-options.21a6d93e.svg"
  },
  {
    "revision": "7b8548491c3101ebf351c57776b7e34b",
    "url": "/static/media/ios-outlet.7b854849.svg"
  },
  {
    "revision": "8e5a6b4c83cfc14d9a84e7d499813985",
    "url": "/static/media/ios-paper-plane.8e5a6b4c.svg"
  },
  {
    "revision": "d549c6769cd1d6d65a3a35740f04c68f",
    "url": "/static/media/ios-paper.d549c676.svg"
  },
  {
    "revision": "a3ff3d09237c5ee94455aafa3297654c",
    "url": "/static/media/ios-partly-sunny.a3ff3d09.svg"
  },
  {
    "revision": "58d97c29436abeb5e9bd69c56de26f06",
    "url": "/static/media/ios-pause.58d97c29.svg"
  },
  {
    "revision": "6ad20a2c13a30192dcee8bb2697959a6",
    "url": "/static/media/ios-paw.6ad20a2c.svg"
  },
  {
    "revision": "5d5e173427d0da36de96c997e5a2ba0f",
    "url": "/static/media/ios-people.5d5e1734.svg"
  },
  {
    "revision": "9b7a219dfe81ebcb46c48d9c40668e64",
    "url": "/static/media/ios-person-add.9b7a219d.svg"
  },
  {
    "revision": "4daea7b9fb43320efcc0671e596520b5",
    "url": "/static/media/ios-person.4daea7b9.svg"
  },
  {
    "revision": "edb7a0aab61f88cd26a25d5268e1104d",
    "url": "/static/media/ios-phone-landscape.edb7a0aa.svg"
  },
  {
    "revision": "df7ab2eb3afc596ca4a6f94fdcc85a71",
    "url": "/static/media/ios-phone-portrait.df7ab2eb.svg"
  },
  {
    "revision": "299d5c0c5f8c5f6bed63715b94c7038c",
    "url": "/static/media/ios-photos.299d5c0c.svg"
  },
  {
    "revision": "07587ea24cef2cc7752b5360038a1a37",
    "url": "/static/media/ios-pie.07587ea2.svg"
  },
  {
    "revision": "cc6b9d96451b56eda7f93b79346c98e6",
    "url": "/static/media/ios-pin.cc6b9d96.svg"
  },
  {
    "revision": "5ff0a21dd62f7436aa9c68a4462ffce6",
    "url": "/static/media/ios-pint.5ff0a21d.svg"
  },
  {
    "revision": "e1b0541445bb3f9ad82784a6e08bc792",
    "url": "/static/media/ios-pizza.e1b05414.svg"
  },
  {
    "revision": "4fd21f9b314c82794e11183845a83fd3",
    "url": "/static/media/ios-planet.4fd21f9b.svg"
  },
  {
    "revision": "51e35ded9954c61997b104f90b10148d",
    "url": "/static/media/ios-play-circle.51e35ded.svg"
  },
  {
    "revision": "1cdd1b8d00cdcb5c59d42881607c7d25",
    "url": "/static/media/ios-play.1cdd1b8d.svg"
  },
  {
    "revision": "35444e01bd48256cb585e67990745909",
    "url": "/static/media/ios-podium.35444e01.svg"
  },
  {
    "revision": "fe60309060cc760e0225e69632107db7",
    "url": "/static/media/ios-power.fe603090.svg"
  },
  {
    "revision": "a80b8a27f6f70e7a89744534543e1799",
    "url": "/static/media/ios-pricetag.a80b8a27.svg"
  },
  {
    "revision": "fd93312d47359e7ee6fada7c099a4cd4",
    "url": "/static/media/ios-pricetags.fd93312d.svg"
  },
  {
    "revision": "4a6774167e358a02be8e3a92f8cc1c1a",
    "url": "/static/media/ios-print.4a677416.svg"
  },
  {
    "revision": "ed9df7e53bdf7a2f8e64b84c1fc23f3c",
    "url": "/static/media/ios-pulse.ed9df7e5.svg"
  },
  {
    "revision": "dee768e12b58d82d49068e6a00ce98cc",
    "url": "/static/media/ios-qr-scanner.dee768e1.svg"
  },
  {
    "revision": "ad581947c72d61e97596365f9bf8c637",
    "url": "/static/media/ios-quote.ad581947.svg"
  },
  {
    "revision": "0a5f679af25200a6830893a16a4a1e8c",
    "url": "/static/media/ios-radio-button-off.0a5f679a.svg"
  },
  {
    "revision": "84d6f619ae6431bf6fc9e98e64caa742",
    "url": "/static/media/ios-radio-button-on.84d6f619.svg"
  },
  {
    "revision": "a8474262b4f13d3ab3c3f0265aa07bf5",
    "url": "/static/media/ios-radio.a8474262.svg"
  },
  {
    "revision": "37dde442dc5affbea561ee471db32b08",
    "url": "/static/media/ios-rainy.37dde442.svg"
  },
  {
    "revision": "c265f295a1cff428164bdf3432ec7e1f",
    "url": "/static/media/ios-recording.c265f295.svg"
  },
  {
    "revision": "b012efa37b13a9dd204c743890f4302c",
    "url": "/static/media/ios-redo.b012efa3.svg"
  },
  {
    "revision": "7f0494dfec1af57735e9b11e588da74b",
    "url": "/static/media/ios-refresh-circle.7f0494df.svg"
  },
  {
    "revision": "428b5e9136475d55bb7acfe52ac70af2",
    "url": "/static/media/ios-refresh.428b5e91.svg"
  },
  {
    "revision": "e545172963d61ddea4ef5718b6e84ffa",
    "url": "/static/media/ios-remove-circle-outline.e5451729.svg"
  },
  {
    "revision": "d6c012a4f7703a37bb019eb6e993e5eb",
    "url": "/static/media/ios-remove-circle.d6c012a4.svg"
  },
  {
    "revision": "f1869ab7fd31c002b57837f411d06868",
    "url": "/static/media/ios-remove.f1869ab7.svg"
  },
  {
    "revision": "2ed71bff58e3a99c71d9814378111dc9",
    "url": "/static/media/ios-reorder.2ed71bff.svg"
  },
  {
    "revision": "d58257afd33bfb89186df8d25c3974bf",
    "url": "/static/media/ios-repeat.d58257af.svg"
  },
  {
    "revision": "f44f2ce3575babf93cb35eb0713c498e",
    "url": "/static/media/ios-resize.f44f2ce3.svg"
  },
  {
    "revision": "7bc0d43c362784831d59132647098415",
    "url": "/static/media/ios-restaurant.7bc0d43c.svg"
  },
  {
    "revision": "20f93ed64c530b8b9ed2d0f7c0f412f7",
    "url": "/static/media/ios-return-left.20f93ed6.svg"
  },
  {
    "revision": "7970de06288d4cd6293784421af376ac",
    "url": "/static/media/ios-return-right.7970de06.svg"
  },
  {
    "revision": "84910f20c92b45925085ce7ee10645a7",
    "url": "/static/media/ios-reverse-camera.84910f20.svg"
  },
  {
    "revision": "791cc679932dc2fab8b45ba7d992ccb8",
    "url": "/static/media/ios-rewind.791cc679.svg"
  },
  {
    "revision": "04d3f464f38e72dd9925c0342ea98673",
    "url": "/static/media/ios-ribbon.04d3f464.svg"
  },
  {
    "revision": "92cc6ee9293b6a355467176c1b64e095",
    "url": "/static/media/ios-rocket.92cc6ee9.svg"
  },
  {
    "revision": "50f82eba7d9685b3f2e0353ffac1b026",
    "url": "/static/media/ios-rose.50f82eba.svg"
  },
  {
    "revision": "0a57378630b89e7aaa92280bbe4d24e7",
    "url": "/static/media/ios-sad.0a573786.svg"
  },
  {
    "revision": "92b47c8de116b2adddb0559c54055789",
    "url": "/static/media/ios-save.92b47c8d.svg"
  },
  {
    "revision": "4c5c54dbb8cb9329ea4d1a3130372fd8",
    "url": "/static/media/ios-school.4c5c54db.svg"
  },
  {
    "revision": "58de3086d267f2f582930c027dffd60e",
    "url": "/static/media/ios-search.58de3086.svg"
  },
  {
    "revision": "1aa8208000b95752375d51b61ae4ebc4",
    "url": "/static/media/ios-send.1aa82080.svg"
  },
  {
    "revision": "975cb155eeb32dd35521d0149902df8e",
    "url": "/static/media/ios-settings.975cb155.svg"
  },
  {
    "revision": "0bf667a10540c76942ab501eaba5e38d",
    "url": "/static/media/ios-share-alt.0bf667a1.svg"
  },
  {
    "revision": "14c727bfa51512be0073ae23adbfb70d",
    "url": "/static/media/ios-share.14c727bf.svg"
  },
  {
    "revision": "bd6ff6e10bb46a5881d52ab6f06091b5",
    "url": "/static/media/ios-shirt.bd6ff6e1.svg"
  },
  {
    "revision": "76b84ba5907596f6c262e2d7fac867a7",
    "url": "/static/media/ios-shuffle.76b84ba5.svg"
  },
  {
    "revision": "533051480121a0fd3fa9df0742c32a93",
    "url": "/static/media/ios-skip-backward.53305148.svg"
  },
  {
    "revision": "148357ac50cc7856ec907dd60f9beabc",
    "url": "/static/media/ios-skip-forward.148357ac.svg"
  },
  {
    "revision": "e00dc9abc4bfc0c87e6353c47f2d055b",
    "url": "/static/media/ios-snow.e00dc9ab.svg"
  },
  {
    "revision": "b111eaafd0b25e6ee93388236497db5c",
    "url": "/static/media/ios-speedometer.b111eaaf.svg"
  },
  {
    "revision": "9b4eececa768cccc2526350868231be6",
    "url": "/static/media/ios-square-outline.9b4eecec.svg"
  },
  {
    "revision": "fe7e060b6e1dbe8b184f9f08ec3bde83",
    "url": "/static/media/ios-square.fe7e060b.svg"
  },
  {
    "revision": "6110aa786ac143b7c94dc6817aaea6ba",
    "url": "/static/media/ios-star-half.6110aa78.svg"
  },
  {
    "revision": "7598789f2b0e1c557f1281df46b59671",
    "url": "/static/media/ios-star-outline.7598789f.svg"
  },
  {
    "revision": "4e4ace472f92cc138820a40ed5075515",
    "url": "/static/media/ios-star.4e4ace47.svg"
  },
  {
    "revision": "1db8674dec9413b7c6572212e9f814e3",
    "url": "/static/media/ios-stats.1db8674d.svg"
  },
  {
    "revision": "7e7e588e28752cd7ad515255496a7aee",
    "url": "/static/media/ios-stopwatch.7e7e588e.svg"
  },
  {
    "revision": "9717dedff606e58f7266f884d4ec8b1d",
    "url": "/static/media/ios-subway.9717dedf.svg"
  },
  {
    "revision": "4cd31fa46947ab308e80834b15d23f3e",
    "url": "/static/media/ios-sunny.4cd31fa4.svg"
  },
  {
    "revision": "e155bcbb60c5530035596888adbadbe5",
    "url": "/static/media/ios-swap.e155bcbb.svg"
  },
  {
    "revision": "66ef4803b0933507b4bcc0eb8cb053a8",
    "url": "/static/media/ios-switch.66ef4803.svg"
  },
  {
    "revision": "1344a6e601ae55de26ab1efe5be0e5c6",
    "url": "/static/media/ios-sync.1344a6e6.svg"
  },
  {
    "revision": "b39f0d6b232f4d9f9dcf3eb6187c0eaa",
    "url": "/static/media/ios-tablet-landscape.b39f0d6b.svg"
  },
  {
    "revision": "f3c810257ffa5e1b0231299f7fe5c629",
    "url": "/static/media/ios-tablet-portrait.f3c81025.svg"
  },
  {
    "revision": "32a84626a02ab514bacc4758ab4ef165",
    "url": "/static/media/ios-tennisball.32a84626.svg"
  },
  {
    "revision": "7785a23452f1e7102154b9026952f643",
    "url": "/static/media/ios-text.7785a234.svg"
  },
  {
    "revision": "ab9af4d0d33bc8a2b0d7cffe5be51758",
    "url": "/static/media/ios-thermometer.ab9af4d0.svg"
  },
  {
    "revision": "b47e5d011f17b0e63b824ecbdef45240",
    "url": "/static/media/ios-thumbs-down.b47e5d01.svg"
  },
  {
    "revision": "beedc6b92e76d827375c3db6a3c714c6",
    "url": "/static/media/ios-thumbs-up.beedc6b9.svg"
  },
  {
    "revision": "b8ef1498a48fc20e985c467de96a377c",
    "url": "/static/media/ios-thunderstorm.b8ef1498.svg"
  },
  {
    "revision": "215ddf1ee409257d6c7384100832c061",
    "url": "/static/media/ios-time.215ddf1e.svg"
  },
  {
    "revision": "c45debb55caf0ea28e9f57846a4a023d",
    "url": "/static/media/ios-timer.c45debb5.svg"
  },
  {
    "revision": "005e2e0372d68f758921199705ce2692",
    "url": "/static/media/ios-today.005e2e03.svg"
  },
  {
    "revision": "368d148dcd5212c71ec5e2c72dc5764a",
    "url": "/static/media/ios-train.368d148d.svg"
  },
  {
    "revision": "db5471e50b033ad3f77fc17e6bf1a973",
    "url": "/static/media/ios-transgender.db5471e5.svg"
  },
  {
    "revision": "ae5afe7da32e0b75443be434d8580dc3",
    "url": "/static/media/ios-trash.ae5afe7d.svg"
  },
  {
    "revision": "6535adf97bed2c2c6d2323d210f7135e",
    "url": "/static/media/ios-trending-down.6535adf9.svg"
  },
  {
    "revision": "e1fa18469d8d81647b5def7221845b95",
    "url": "/static/media/ios-trending-up.e1fa1846.svg"
  },
  {
    "revision": "18ebe4958235ac0ab081e47a2a4f036d",
    "url": "/static/media/ios-trophy.18ebe495.svg"
  },
  {
    "revision": "5a506830a5ba6fb5a4b3592d7c684741",
    "url": "/static/media/ios-tv.5a506830.svg"
  },
  {
    "revision": "0003d71091cd49e526942285c5813654",
    "url": "/static/media/ios-umbrella.0003d710.svg"
  },
  {
    "revision": "953f1d72b1169faf6e461c94955d702f",
    "url": "/static/media/ios-undo.953f1d72.svg"
  },
  {
    "revision": "6d95127258d47b4f70ba505a0347e80b",
    "url": "/static/media/ios-unlock.6d951272.svg"
  },
  {
    "revision": "b51e8684b6e34306852e242d76c01728",
    "url": "/static/media/ios-videocam.b51e8684.svg"
  },
  {
    "revision": "2dc2b656b760a4bf9bae52be2acc17a5",
    "url": "/static/media/ios-volume-high.2dc2b656.svg"
  },
  {
    "revision": "cde172bfce48bda8929ef53a75a00b98",
    "url": "/static/media/ios-volume-low.cde172bf.svg"
  },
  {
    "revision": "66e5ba218b608319ea65a2f465fc7d7b",
    "url": "/static/media/ios-volume-mute.66e5ba21.svg"
  },
  {
    "revision": "287ed2193008bfafd58ea4ee9aaf1cb6",
    "url": "/static/media/ios-volume-off.287ed219.svg"
  },
  {
    "revision": "9dc33df596ce5a2203d37e1f54837814",
    "url": "/static/media/ios-walk.9dc33df5.svg"
  },
  {
    "revision": "1e51b0c17c1f45d23e78ad85eaf45200",
    "url": "/static/media/ios-wallet.1e51b0c1.svg"
  },
  {
    "revision": "c094c1c9f6648359c7998ef3679b490a",
    "url": "/static/media/ios-warning.c094c1c9.svg"
  },
  {
    "revision": "1c1a661a92a399dc034aa150a4f9f6bd",
    "url": "/static/media/ios-watch.1c1a661a.svg"
  },
  {
    "revision": "81decf06f84f73f97220a9264572b580",
    "url": "/static/media/ios-water.81decf06.svg"
  },
  {
    "revision": "85d949598a5ad2ee8faa609caf450122",
    "url": "/static/media/ios-wifi.85d94959.svg"
  },
  {
    "revision": "15e329a44fa625a04ac7218e8b819ba8",
    "url": "/static/media/ios-wine.15e329a4.svg"
  },
  {
    "revision": "05033c78a68abf3c9398b264a30578ee",
    "url": "/static/media/ios-woman.05033c78.svg"
  },
  {
    "revision": "90adbe1d43fc60cd0dddb5784ef8dad5",
    "url": "/static/media/logo-android.90adbe1d.svg"
  },
  {
    "revision": "c42a69d0d3c830fc19756b7cfcad5b83",
    "url": "/static/media/logo-angular.c42a69d0.svg"
  },
  {
    "revision": "b2c62065db8630af8c6b8119929bbdf5",
    "url": "/static/media/logo-apple.b2c62065.svg"
  },
  {
    "revision": "4f9455bcbed93700bd739beb33b27ff0",
    "url": "/static/media/logo-bitbucket.4f9455bc.svg"
  },
  {
    "revision": "4fd2e1b84409e04903a4df1f385247ce",
    "url": "/static/media/logo-bitcoin.4fd2e1b8.svg"
  },
  {
    "revision": "c60ed6c246088e267e7d5e3f2c1909d6",
    "url": "/static/media/logo-buffer.c60ed6c2.svg"
  },
  {
    "revision": "f22827522cf30339d4d5fd6a20cb716f",
    "url": "/static/media/logo-chrome.f2282752.svg"
  },
  {
    "revision": "5a1ebda9793a31a8442a9195b8149503",
    "url": "/static/media/logo-closed-captioning.5a1ebda9.svg"
  },
  {
    "revision": "5bd8e715dcc675bad6d25536fa6d3aed",
    "url": "/static/media/logo-codepen.5bd8e715.svg"
  },
  {
    "revision": "5c44e01d3e2611c14c4c07959335e765",
    "url": "/static/media/logo-css3.5c44e01d.svg"
  },
  {
    "revision": "948250b1fd19cb11dd4c9067b13508b0",
    "url": "/static/media/logo-designernews.948250b1.svg"
  },
  {
    "revision": "d4f5af0d33557ad7e8663403107c2cd9",
    "url": "/static/media/logo-dribbble.d4f5af0d.svg"
  },
  {
    "revision": "3f0350ccc775c035ca27a12c9712714b",
    "url": "/static/media/logo-dropbox.3f0350cc.svg"
  },
  {
    "revision": "a064e736d3e98fb9ab63372c95489536",
    "url": "/static/media/logo-euro.a064e736.svg"
  },
  {
    "revision": "46c0bd59adb9b6ca394698fd6169b290",
    "url": "/static/media/logo-facebook.46c0bd59.svg"
  },
  {
    "revision": "52aaffb84b1110a30b01937f14e491c3",
    "url": "/static/media/logo-flickr.52aaffb8.svg"
  },
  {
    "revision": "da8be88cca5758f64b9c1d7f84c25f4c",
    "url": "/static/media/logo-foursquare.da8be88c.svg"
  },
  {
    "revision": "08a0c13bb56d065958f3acfb380ffdca",
    "url": "/static/media/logo-freebsd-devil.08a0c13b.svg"
  },
  {
    "revision": "125017890adc06dc3886ff3e4ac64cbe",
    "url": "/static/media/logo-game-controller-a.12501789.svg"
  },
  {
    "revision": "17a42e12798ced07697dcdc808f32f8c",
    "url": "/static/media/logo-game-controller-b.17a42e12.svg"
  },
  {
    "revision": "8a1ba32d3c7b69b57d05b74cd65d8bd8",
    "url": "/static/media/logo-github.8a1ba32d.svg"
  },
  {
    "revision": "4af031c17f7b7b42a97a16ec770533d2",
    "url": "/static/media/logo-google.4af031c1.svg"
  },
  {
    "revision": "f5e50927c03163e3b7541c6c4c6a6e03",
    "url": "/static/media/logo-googleplus.f5e50927.svg"
  },
  {
    "revision": "c92a375d8431b0db600c04ef06545f94",
    "url": "/static/media/logo-hackernews.c92a375d.svg"
  },
  {
    "revision": "0263f883f26af732e1247b14c2f54554",
    "url": "/static/media/logo-html5.0263f883.svg"
  },
  {
    "revision": "c1dbcbd5a81080b7bc53b98bac4d58bd",
    "url": "/static/media/logo-instagram.c1dbcbd5.svg"
  },
  {
    "revision": "b69346c0b3d644fc3423737c759386cd",
    "url": "/static/media/logo-ionic.b69346c0.svg"
  },
  {
    "revision": "057a6c2f4f5702234c930ba5bd190303",
    "url": "/static/media/logo-ionitron.057a6c2f.svg"
  },
  {
    "revision": "bbbb150f373830da06e505b1417fb224",
    "url": "/static/media/logo-javascript.bbbb150f.svg"
  },
  {
    "revision": "8dc04bcddc1ee128393621e994aa53e9",
    "url": "/static/media/logo-linkedin.8dc04bcd.svg"
  },
  {
    "revision": "ae7fedcb760e58adcdbe3ade91dc5ab7",
    "url": "/static/media/logo-markdown.ae7fedcb.svg"
  },
  {
    "revision": "7d58a5563fe1bcad2ec2eff48e2f4e4a",
    "url": "/static/media/logo-model-s.7d58a556.svg"
  },
  {
    "revision": "e3c2c91b470b4f2080042a6687f117d2",
    "url": "/static/media/logo-no-smoking.e3c2c91b.svg"
  },
  {
    "revision": "5d51536dbeed616207e8a4babbe05f06",
    "url": "/static/media/logo-nodejs.5d51536d.svg"
  },
  {
    "revision": "d631bf074d6369698db34fc91a2032c6",
    "url": "/static/media/logo-npm.d631bf07.svg"
  },
  {
    "revision": "3bdb0ef92d6a5abd55077b07c6f5c9e7",
    "url": "/static/media/logo-octocat.3bdb0ef9.svg"
  },
  {
    "revision": "870c40e99753b17c32a12c219b6673ed",
    "url": "/static/media/logo-pinterest.870c40e9.svg"
  },
  {
    "revision": "80ff12448b7ff993e6453592601f0151",
    "url": "/static/media/logo-playstation.80ff1244.svg"
  },
  {
    "revision": "7d0fc3520324c1ff920f246abe405c09",
    "url": "/static/media/logo-polymer.7d0fc352.svg"
  },
  {
    "revision": "7759b8cdcc1f4b9970d5ad2138fca7c3",
    "url": "/static/media/logo-python.7759b8cd.svg"
  },
  {
    "revision": "4ee9a163ce3cef1ee01386acdf962f4f",
    "url": "/static/media/logo-reddit.4ee9a163.svg"
  },
  {
    "revision": "b2f31e4d95a8779581373d0e582df485",
    "url": "/static/media/logo-rss.b2f31e4d.svg"
  },
  {
    "revision": "9796e80bdf604b9bfca6584ca040882c",
    "url": "/static/media/logo-sass.9796e80b.svg"
  },
  {
    "revision": "2ff8f84c02ee2da7a34777dd133a896b",
    "url": "/static/media/logo-skype.2ff8f84c.svg"
  },
  {
    "revision": "e88bf77bea55e0983ec683a3c3d5746a",
    "url": "/static/media/logo-slack.e88bf77b.svg"
  },
  {
    "revision": "9c8aede73190ef36696adbd84258827d",
    "url": "/static/media/logo-snapchat.9c8aede7.svg"
  },
  {
    "revision": "81116cd26b179b7d9dc6d28208a56331",
    "url": "/static/media/logo-steam.81116cd2.svg"
  },
  {
    "revision": "a3f62e3341429e766ef43c9742e918ba",
    "url": "/static/media/logo-tumblr.a3f62e33.svg"
  },
  {
    "revision": "edfd5dafc7176845016b623c55b4c58c",
    "url": "/static/media/logo-tux.edfd5daf.svg"
  },
  {
    "revision": "cd5a611bb5b92548c42f41de823ce35a",
    "url": "/static/media/logo-twitch.cd5a611b.svg"
  },
  {
    "revision": "3ee3ca382ffca890ed37a4b96d876520",
    "url": "/static/media/logo-twitter.3ee3ca38.svg"
  },
  {
    "revision": "8b88ec035f5b719a276b4e0b88788663",
    "url": "/static/media/logo-usd.8b88ec03.svg"
  },
  {
    "revision": "8f0c9d7b567e0f5408790999953be553",
    "url": "/static/media/logo-vimeo.8f0c9d7b.svg"
  },
  {
    "revision": "5d4d40d52c08496d7bca7d4bca4efafa",
    "url": "/static/media/logo-vk.5d4d40d5.svg"
  },
  {
    "revision": "9bb37426825be86581faef88a8e2ccb0",
    "url": "/static/media/logo-whatsapp.9bb37426.svg"
  },
  {
    "revision": "45fff7fb6e29a4fca9efc75d5116672c",
    "url": "/static/media/logo-windows.45fff7fb.svg"
  },
  {
    "revision": "f033eb3714042ccb8dc0588d9fcdfda0",
    "url": "/static/media/logo-wordpress.f033eb37.svg"
  },
  {
    "revision": "d065e077b0db88e12f28d1f1e9c89ad4",
    "url": "/static/media/logo-xbox.d065e077.svg"
  },
  {
    "revision": "ba7d9b7922fd255b9ccbd91df20d9ad5",
    "url": "/static/media/logo-xing.ba7d9b79.svg"
  },
  {
    "revision": "1738d03e3dc3f0ab6679c002f057223b",
    "url": "/static/media/logo-yahoo.1738d03e.svg"
  },
  {
    "revision": "94a9e893ecc56f42bc953c8bc6f3700e",
    "url": "/static/media/logo-yen.94a9e893.svg"
  },
  {
    "revision": "bad4875ed0a61c355ddb47027475f085",
    "url": "/static/media/logo-youtube.bad4875e.svg"
  },
  {
    "revision": "4718a715c260fb27aa5d1a5c5dd4f25c",
    "url": "/static/media/md-add-circle-outline.4718a715.svg"
  },
  {
    "revision": "85393ba81074efe26a46fc4b7b9165ae",
    "url": "/static/media/md-add-circle.85393ba8.svg"
  },
  {
    "revision": "9029975fcba35c972376396c12313ecc",
    "url": "/static/media/md-add.9029975f.svg"
  },
  {
    "revision": "9f993609826199e0633d2e0324f732c9",
    "url": "/static/media/md-airplane.9f993609.svg"
  },
  {
    "revision": "054fbf090d6c18e5e8cbfa6f750decdb",
    "url": "/static/media/md-alarm.054fbf09.svg"
  },
  {
    "revision": "f301f66fe04cbd720ced1d2eaaa261a3",
    "url": "/static/media/md-albums.f301f66f.svg"
  },
  {
    "revision": "0b9ca738ae164956640e2da2c8795946",
    "url": "/static/media/md-alert.0b9ca738.svg"
  },
  {
    "revision": "9667d2506fbe97684f1732ea59b3635b",
    "url": "/static/media/md-american-football.9667d250.svg"
  },
  {
    "revision": "2688d275f453921cdca656941f212ea7",
    "url": "/static/media/md-analytics.2688d275.svg"
  },
  {
    "revision": "189866de0dc883aa32565246793e0bf4",
    "url": "/static/media/md-aperture.189866de.svg"
  },
  {
    "revision": "1bf175220e4119197ce1277a1b44fad1",
    "url": "/static/media/md-apps.1bf17522.svg"
  },
  {
    "revision": "f9892ac336b898a64478d474f5b5cb78",
    "url": "/static/media/md-appstore.f9892ac3.svg"
  },
  {
    "revision": "e337d19639a0ddf73c09f9ac2217e504",
    "url": "/static/media/md-archive.e337d196.svg"
  },
  {
    "revision": "f281d4c64384c6e7efd1fa4097b7d3f7",
    "url": "/static/media/md-arrow-back.f281d4c6.svg"
  },
  {
    "revision": "347a40057096cc1278d48a4f46e7f8e1",
    "url": "/static/media/md-arrow-down.347a4005.svg"
  },
  {
    "revision": "fc0c4c1efb6d0586c2c27020943f06a1",
    "url": "/static/media/md-arrow-dropdown-circle.fc0c4c1e.svg"
  },
  {
    "revision": "b21e90ec8db8032cced62a87578606f6",
    "url": "/static/media/md-arrow-dropdown.b21e90ec.svg"
  },
  {
    "revision": "34ef151528d744f29f084810738ea826",
    "url": "/static/media/md-arrow-dropleft-circle.34ef1515.svg"
  },
  {
    "revision": "4ffa51aeb0e75db0a4e3dbfcf50c6f7e",
    "url": "/static/media/md-arrow-dropleft.4ffa51ae.svg"
  },
  {
    "revision": "c3db11891317dff5ad2c2ed4e1c1edd4",
    "url": "/static/media/md-arrow-dropright-circle.c3db1189.svg"
  },
  {
    "revision": "7666daaa1131424248073bf3b7d8ba76",
    "url": "/static/media/md-arrow-dropright.7666daaa.svg"
  },
  {
    "revision": "43c410cff8e20d5d766d62e999339cc5",
    "url": "/static/media/md-arrow-dropup-circle.43c410cf.svg"
  },
  {
    "revision": "bd452c7b264dc94ca175fee3af7766b8",
    "url": "/static/media/md-arrow-dropup.bd452c7b.svg"
  },
  {
    "revision": "962cbfb7fedc5b9a533f3677d8056b41",
    "url": "/static/media/md-arrow-forward.962cbfb7.svg"
  },
  {
    "revision": "99fa174cd8667e43b64d82dede27acde",
    "url": "/static/media/md-arrow-round-back.99fa174c.svg"
  },
  {
    "revision": "900a59b80c5dadc5786607ddf6b5c251",
    "url": "/static/media/md-arrow-round-down.900a59b8.svg"
  },
  {
    "revision": "90d74733ca89f01279e10f4a4af9ed98",
    "url": "/static/media/md-arrow-round-forward.90d74733.svg"
  },
  {
    "revision": "a52337f9ea408366831dfc6b2e0b7cd8",
    "url": "/static/media/md-arrow-round-up.a52337f9.svg"
  },
  {
    "revision": "46ca744e25ed9e69d234eaf0ec4d7b82",
    "url": "/static/media/md-arrow-up.46ca744e.svg"
  },
  {
    "revision": "6aaca585a22b8df9de10fa1dd0eb8170",
    "url": "/static/media/md-at.6aaca585.svg"
  },
  {
    "revision": "fa27bcf0e95d3d32d448510063dfa866",
    "url": "/static/media/md-attach.fa27bcf0.svg"
  },
  {
    "revision": "78d2783941e69f7ae120edd8434d274a",
    "url": "/static/media/md-backspace.78d27839.svg"
  },
  {
    "revision": "8973283eb37fba336ec460420fae4518",
    "url": "/static/media/md-barcode.8973283e.svg"
  },
  {
    "revision": "15e7aaf4dbcb93d614187c9d4d6f06d4",
    "url": "/static/media/md-baseball.15e7aaf4.svg"
  },
  {
    "revision": "609963fa037a976991ae4dd4f32afc93",
    "url": "/static/media/md-basket.609963fa.svg"
  },
  {
    "revision": "f0bd29bb2dfc7391316af6c563bfd67f",
    "url": "/static/media/md-basketball.f0bd29bb.svg"
  },
  {
    "revision": "71537640f96797ad01b62bade961bddf",
    "url": "/static/media/md-battery-charging.71537640.svg"
  },
  {
    "revision": "508de4ebef41368622f25e6924e98c8d",
    "url": "/static/media/md-battery-dead.508de4eb.svg"
  },
  {
    "revision": "da14b321da824f4f110960387298f615",
    "url": "/static/media/md-battery-full.da14b321.svg"
  },
  {
    "revision": "f8edfa3716e00e08f8c211f64af6487b",
    "url": "/static/media/md-beaker.f8edfa37.svg"
  },
  {
    "revision": "25813fa67960663664dd7a94cd12e612",
    "url": "/static/media/md-bed.25813fa6.svg"
  },
  {
    "revision": "ffbef646ac3ec3b99af7e735f9ce4fad",
    "url": "/static/media/md-beer.ffbef646.svg"
  },
  {
    "revision": "c93a92ab80dad6471449ef567297dc4d",
    "url": "/static/media/md-bicycle.c93a92ab.svg"
  },
  {
    "revision": "4bd9a202acdddb2db5d1bf31f9b30f8a",
    "url": "/static/media/md-bluetooth.4bd9a202.svg"
  },
  {
    "revision": "043fbf8d9b1a6daaf30d4633e6c2c94b",
    "url": "/static/media/md-boat.043fbf8d.svg"
  },
  {
    "revision": "2bd3674a20535f35c5f03ec0879b26c5",
    "url": "/static/media/md-body.2bd3674a.svg"
  },
  {
    "revision": "fe5a813443f4be66959f676e364c5b7f",
    "url": "/static/media/md-bonfire.fe5a8134.svg"
  },
  {
    "revision": "11d6816c1e0413ef3ba7b478b6300d93",
    "url": "/static/media/md-book.11d6816c.svg"
  },
  {
    "revision": "4079d6ccf132c447990abb37dd5bb351",
    "url": "/static/media/md-bookmark.4079d6cc.svg"
  },
  {
    "revision": "c2172fa0f5f55857a4296284f12452da",
    "url": "/static/media/md-bookmarks.c2172fa0.svg"
  },
  {
    "revision": "9a611b96b6cb0491446bb5b10ffbd527",
    "url": "/static/media/md-bowtie.9a611b96.svg"
  },
  {
    "revision": "bca8927d47a572d091adde6a34101051",
    "url": "/static/media/md-briefcase.bca8927d.svg"
  },
  {
    "revision": "5b3027fe5830552d297c518f0474b18b",
    "url": "/static/media/md-browsers.5b3027fe.svg"
  },
  {
    "revision": "3bdbc645be6ed4c5dec9b7577efd51f5",
    "url": "/static/media/md-brush.3bdbc645.svg"
  },
  {
    "revision": "a7d3542abfa52c9004a33f3d6b018002",
    "url": "/static/media/md-bug.a7d3542a.svg"
  },
  {
    "revision": "b360dc24090b494e13fa1109d1f54cba",
    "url": "/static/media/md-build.b360dc24.svg"
  },
  {
    "revision": "e9e755f4173db4160d9ea6071e2eff3d",
    "url": "/static/media/md-bulb.e9e755f4.svg"
  },
  {
    "revision": "52a105e40643802fb54250592bd2c982",
    "url": "/static/media/md-bus.52a105e4.svg"
  },
  {
    "revision": "6b54fc901d33ef0d04deb83fcc626e7d",
    "url": "/static/media/md-business.6b54fc90.svg"
  },
  {
    "revision": "976350ecf514a412324afe168eb7d94b",
    "url": "/static/media/md-cafe.976350ec.svg"
  },
  {
    "revision": "c6ca35a8a07ec3e928d8a1e1df3dc3ad",
    "url": "/static/media/md-calculator.c6ca35a8.svg"
  },
  {
    "revision": "00ef4085a985384c3092fa0a5be6d6e5",
    "url": "/static/media/md-calendar.00ef4085.svg"
  },
  {
    "revision": "719ec3ec9151bed1084ec8b76338e9f3",
    "url": "/static/media/md-call.719ec3ec.svg"
  },
  {
    "revision": "464fa575a82e1c30137559435162d297",
    "url": "/static/media/md-camera.464fa575.svg"
  },
  {
    "revision": "c9f0a754476881b6aab74f2485652a80",
    "url": "/static/media/md-car.c9f0a754.svg"
  },
  {
    "revision": "37ae7a5d6c38dc2bfe9f1c3230d5a743",
    "url": "/static/media/md-card.37ae7a5d.svg"
  },
  {
    "revision": "40fe4e3a010b4c30e2fb2ec269d4d2c7",
    "url": "/static/media/md-cart.40fe4e3a.svg"
  },
  {
    "revision": "51d067e099b421e43d376a1678260db3",
    "url": "/static/media/md-cash.51d067e0.svg"
  },
  {
    "revision": "eb6f210ece658d1b2adae5ecdac6d79b",
    "url": "/static/media/md-cellular.eb6f210e.svg"
  },
  {
    "revision": "91b10fb50ea37c7069ecf2fcdd93f5f0",
    "url": "/static/media/md-chatboxes.91b10fb5.svg"
  },
  {
    "revision": "c391d90d6c74cb42ac34470660a1edc8",
    "url": "/static/media/md-chatbubbles.c391d90d.svg"
  },
  {
    "revision": "c7502861bd4abac401955102e834c39f",
    "url": "/static/media/md-checkbox-outline.c7502861.svg"
  },
  {
    "revision": "88cf0db199d12661c85b7c9e4623d893",
    "url": "/static/media/md-checkbox.88cf0db1.svg"
  },
  {
    "revision": "326664188389be9fc497c8bb3e994995",
    "url": "/static/media/md-checkmark-circle-outline.32666418.svg"
  },
  {
    "revision": "a49f05e9e01777c6030bce337a75fdf0",
    "url": "/static/media/md-checkmark-circle.a49f05e9.svg"
  },
  {
    "revision": "984edddf649952c69f697fce0ac592f9",
    "url": "/static/media/md-checkmark.984edddf.svg"
  },
  {
    "revision": "8b029cfd9d708aa62bfe961fcd2e1c0b",
    "url": "/static/media/md-clipboard.8b029cfd.svg"
  },
  {
    "revision": "413c314ab9b1c04f9b9baa824d69fe7e",
    "url": "/static/media/md-clock.413c314a.svg"
  },
  {
    "revision": "629b03c85cc813439787c3734886c453",
    "url": "/static/media/md-close-circle-outline.629b03c8.svg"
  },
  {
    "revision": "5ecf73b45141861ff124fa3e7fd5c98d",
    "url": "/static/media/md-close-circle.5ecf73b4.svg"
  },
  {
    "revision": "e56f70f89faba013eb18243dfb94ef53",
    "url": "/static/media/md-close.e56f70f8.svg"
  },
  {
    "revision": "60e4a811e7260ce88628d119201b61f5",
    "url": "/static/media/md-cloud-circle.60e4a811.svg"
  },
  {
    "revision": "ebcd53f3c4f421917adda6b72900ccda",
    "url": "/static/media/md-cloud-done.ebcd53f3.svg"
  },
  {
    "revision": "47419780f6f7c4aed5d524ff2076d2e1",
    "url": "/static/media/md-cloud-download.47419780.svg"
  },
  {
    "revision": "76d2f12b7cd633a93996d58936916880",
    "url": "/static/media/md-cloud-outline.76d2f12b.svg"
  },
  {
    "revision": "0c07424823e51431a676e0ae922adc5e",
    "url": "/static/media/md-cloud-upload.0c074248.svg"
  },
  {
    "revision": "985f537b7bf7673a8b22383c1d3f39ff",
    "url": "/static/media/md-cloud.985f537b.svg"
  },
  {
    "revision": "4cc78e9277bd99d1ef28ada36d68b470",
    "url": "/static/media/md-cloudy-night.4cc78e92.svg"
  },
  {
    "revision": "a7527ae4c54e64e64f63b41e1ba2dc68",
    "url": "/static/media/md-cloudy.a7527ae4.svg"
  },
  {
    "revision": "5845b2cdaa274ac9de15e7013d694e79",
    "url": "/static/media/md-code-download.5845b2cd.svg"
  },
  {
    "revision": "2b0e1bb37cc79194720a7785930099d8",
    "url": "/static/media/md-code-working.2b0e1bb3.svg"
  },
  {
    "revision": "6313a2f3e4df52f0c7d277ac1ae47bbb",
    "url": "/static/media/md-code.6313a2f3.svg"
  },
  {
    "revision": "c952e3bb335100cc57b027262f69812f",
    "url": "/static/media/md-cog.c952e3bb.svg"
  },
  {
    "revision": "280e2ce1d61d7ae4eca6417b0ad5262a",
    "url": "/static/media/md-color-fill.280e2ce1.svg"
  },
  {
    "revision": "7058497fb6edd904df451c53b18f1c8a",
    "url": "/static/media/md-color-filter.7058497f.svg"
  },
  {
    "revision": "019a16f4b2ca052451179c80816eafae",
    "url": "/static/media/md-color-palette.019a16f4.svg"
  },
  {
    "revision": "cc9341d051d21184a1d91d3d8888e10d",
    "url": "/static/media/md-color-wand.cc9341d0.svg"
  },
  {
    "revision": "eb8092afc05e1640785b3018f867add4",
    "url": "/static/media/md-compass.eb8092af.svg"
  },
  {
    "revision": "1aacb946da683c43227a9b2ce6f24706",
    "url": "/static/media/md-construct.1aacb946.svg"
  },
  {
    "revision": "493ed010b9482d01f35c9b17a6666d4e",
    "url": "/static/media/md-contact.493ed010.svg"
  },
  {
    "revision": "2146769b4cbcf0eb5d1272ac749985cd",
    "url": "/static/media/md-contacts.2146769b.svg"
  },
  {
    "revision": "488ef4f4f693f2c27bc51c573b276130",
    "url": "/static/media/md-contract.488ef4f4.svg"
  },
  {
    "revision": "7f808d2fdf5240b84369987d1a89598a",
    "url": "/static/media/md-contrast.7f808d2f.svg"
  },
  {
    "revision": "1fde2908bc5b0ab2edd3f147258b7cc9",
    "url": "/static/media/md-copy.1fde2908.svg"
  },
  {
    "revision": "d93204ce3d393b61665298db29db4e6a",
    "url": "/static/media/md-create.d93204ce.svg"
  },
  {
    "revision": "988702a3b49d67eafd8cdf88b56c668f",
    "url": "/static/media/md-crop.988702a3.svg"
  },
  {
    "revision": "9e89bea7d1b3612a0d01aee731411fbf",
    "url": "/static/media/md-cube.9e89bea7.svg"
  },
  {
    "revision": "126dd5421c22ef0cc7cf105ffd36c0b7",
    "url": "/static/media/md-cut.126dd542.svg"
  },
  {
    "revision": "8e16a89401feb9e52f92edd723b343f2",
    "url": "/static/media/md-desktop.8e16a894.svg"
  },
  {
    "revision": "2ed012e493e16eee5388209736ecc3e7",
    "url": "/static/media/md-disc.2ed012e4.svg"
  },
  {
    "revision": "9d31a249244d249bc4f3eab7028b3ba4",
    "url": "/static/media/md-document.9d31a249.svg"
  },
  {
    "revision": "0657748a01ea034bb8f33ac20095a83a",
    "url": "/static/media/md-done-all.0657748a.svg"
  },
  {
    "revision": "8e10a5c8b57464a175242f98033d6a77",
    "url": "/static/media/md-download.8e10a5c8.svg"
  },
  {
    "revision": "9f884ca9a0210a196f8048fd5e169297",
    "url": "/static/media/md-easel.9f884ca9.svg"
  },
  {
    "revision": "d883660a1c8681705583d918e367837d",
    "url": "/static/media/md-egg.d883660a.svg"
  },
  {
    "revision": "b2136cd65cace69039c88b6b6718e5d0",
    "url": "/static/media/md-exit.b2136cd6.svg"
  },
  {
    "revision": "82e1cfaeb0d992aa80599935097f4617",
    "url": "/static/media/md-expand.82e1cfae.svg"
  },
  {
    "revision": "4227037ae1f358fed1ffb780ffad38f6",
    "url": "/static/media/md-eye-off.4227037a.svg"
  },
  {
    "revision": "26d4b395d17d49c27605333ebfb96322",
    "url": "/static/media/md-eye.26d4b395.svg"
  },
  {
    "revision": "4b948df75957c7ba06e5bd4dfcf081bc",
    "url": "/static/media/md-fastforward.4b948df7.svg"
  },
  {
    "revision": "01eebeb5bdd888787f19b282a7d14b8d",
    "url": "/static/media/md-female.01eebeb5.svg"
  },
  {
    "revision": "e019d3c26f8ac09d472d584d20e67a50",
    "url": "/static/media/md-filing.e019d3c2.svg"
  },
  {
    "revision": "8c95b4112f3bf944fb37912f13f939da",
    "url": "/static/media/md-film.8c95b411.svg"
  },
  {
    "revision": "2d6d65762f04ae27123c1d34a7cadb3c",
    "url": "/static/media/md-finger-print.2d6d6576.svg"
  },
  {
    "revision": "b22471b4c695c859567dc1ef84c6ba32",
    "url": "/static/media/md-fitness.b22471b4.svg"
  },
  {
    "revision": "87ab61b1913e3fc4f623bc8f5507e366",
    "url": "/static/media/md-flag.87ab61b1.svg"
  },
  {
    "revision": "64a3f009d601f567b467a0fadabfb820",
    "url": "/static/media/md-flame.64a3f009.svg"
  },
  {
    "revision": "0f8afb6492b4ceeae6f4ff35ddf0fa06",
    "url": "/static/media/md-flash-off.0f8afb64.svg"
  },
  {
    "revision": "6566bae51b97c366362e6fdd17249897",
    "url": "/static/media/md-flash.6566bae5.svg"
  },
  {
    "revision": "473a1f65a359efe3db7fb2102cee264c",
    "url": "/static/media/md-flashlight.473a1f65.svg"
  },
  {
    "revision": "e43b1120640843e722d31256f52be5bf",
    "url": "/static/media/md-flask.e43b1120.svg"
  },
  {
    "revision": "e226ba32fba1191588c75b119ce5ef08",
    "url": "/static/media/md-flower.e226ba32.svg"
  },
  {
    "revision": "ba66422afe508f9bd25a243759c0b298",
    "url": "/static/media/md-folder-open.ba66422a.svg"
  },
  {
    "revision": "d95b089777bd56c578dfc889b0dd38b2",
    "url": "/static/media/md-folder.d95b0897.svg"
  },
  {
    "revision": "f661b75c5b2ac9f789544e6564d17cb7",
    "url": "/static/media/md-football.f661b75c.svg"
  },
  {
    "revision": "6315ebed62eb24afaf34733b60a6a413",
    "url": "/static/media/md-funnel.6315ebed.svg"
  },
  {
    "revision": "de8beff106533db7a7ae535c9b1cbc10",
    "url": "/static/media/md-gift.de8beff1.svg"
  },
  {
    "revision": "b88659c382f0c33b92346a3b592f9c32",
    "url": "/static/media/md-git-branch.b88659c3.svg"
  },
  {
    "revision": "7c36d11c426850ee8d75221ce75c6a7b",
    "url": "/static/media/md-git-commit.7c36d11c.svg"
  },
  {
    "revision": "553bbeceb55c563af35cc2c7fea72e83",
    "url": "/static/media/md-git-compare.553bbece.svg"
  },
  {
    "revision": "71f5d12f2591e34710c9f46887f9631c",
    "url": "/static/media/md-git-merge.71f5d12f.svg"
  },
  {
    "revision": "7e6b60718104b5add2db0add2343bac7",
    "url": "/static/media/md-git-network.7e6b6071.svg"
  },
  {
    "revision": "4a5595be107458b27db518fa3e402c11",
    "url": "/static/media/md-git-pull-request.4a5595be.svg"
  },
  {
    "revision": "af2072163f819f3db5629bdbddf59e31",
    "url": "/static/media/md-glasses.af207216.svg"
  },
  {
    "revision": "a71da31cb6b3126602072330c3a8a428",
    "url": "/static/media/md-globe.a71da31c.svg"
  },
  {
    "revision": "4199c4aaf500dc4aa52b0c87c941c249",
    "url": "/static/media/md-grid.4199c4aa.svg"
  },
  {
    "revision": "4b5f5a3f36f1faa979aafbeaa6d9ab33",
    "url": "/static/media/md-hammer.4b5f5a3f.svg"
  },
  {
    "revision": "3735622c86823e481b931526f2e7aa20",
    "url": "/static/media/md-hand.3735622c.svg"
  },
  {
    "revision": "1766c2c3630e7e638db255b8a6bb147a",
    "url": "/static/media/md-happy.1766c2c3.svg"
  },
  {
    "revision": "9f82757708994ddfeb5b5ba26865cf81",
    "url": "/static/media/md-headset.9f827577.svg"
  },
  {
    "revision": "aaeb7a8ffd26c9d6e2edccfdd8ff9f3e",
    "url": "/static/media/md-heart-dislike.aaeb7a8f.svg"
  },
  {
    "revision": "8b8cfd844d9bf8176a8f4689d9b80726",
    "url": "/static/media/md-heart-empty.8b8cfd84.svg"
  },
  {
    "revision": "f6111402b0dee1d58e4066a3d719f3ec",
    "url": "/static/media/md-heart-half.f6111402.svg"
  },
  {
    "revision": "cf814990e60b7e8da93f8a33aa46d0f8",
    "url": "/static/media/md-heart.cf814990.svg"
  },
  {
    "revision": "3748193b1b82886223be34cfbf613660",
    "url": "/static/media/md-help-buoy.3748193b.svg"
  },
  {
    "revision": "ac7620f1bf69d98b45965faa203ba336",
    "url": "/static/media/md-help-circle-outline.ac7620f1.svg"
  },
  {
    "revision": "4c8033641938e20dba1a4b24a1be9c85",
    "url": "/static/media/md-help-circle.4c803364.svg"
  },
  {
    "revision": "327916e35f4127b74a2b4ddf15327bf2",
    "url": "/static/media/md-help.327916e3.svg"
  },
  {
    "revision": "78d6e460cb5d3888b1f440f47cad8ff9",
    "url": "/static/media/md-home.78d6e460.svg"
  },
  {
    "revision": "6905b8dd9914e49643051182dcb38dfe",
    "url": "/static/media/md-hourglass.6905b8dd.svg"
  },
  {
    "revision": "3f2b94c32416c226048eddd047be279d",
    "url": "/static/media/md-ice-cream.3f2b94c3.svg"
  },
  {
    "revision": "a0c49aaef1878c110cc2398ddb5e0c29",
    "url": "/static/media/md-image.a0c49aae.svg"
  },
  {
    "revision": "16c79cf35d41d5059f758f7e6f80ff6c",
    "url": "/static/media/md-images.16c79cf3.svg"
  },
  {
    "revision": "23fe6eb070fe9ddcfbf7a7e8d81c2dc8",
    "url": "/static/media/md-infinite.23fe6eb0.svg"
  },
  {
    "revision": "d2e3e7f99c12e62f70dd6248bfe5fe9a",
    "url": "/static/media/md-information-circle-outline.d2e3e7f9.svg"
  },
  {
    "revision": "8e5cce1725be4a020357cd9cf12b33b7",
    "url": "/static/media/md-information-circle.8e5cce17.svg"
  },
  {
    "revision": "499bd6bc8db64a44d01c6b5724965235",
    "url": "/static/media/md-information.499bd6bc.svg"
  },
  {
    "revision": "4af3957c690ae08dcb818838a72f11e3",
    "url": "/static/media/md-jet.4af3957c.svg"
  },
  {
    "revision": "e4ba680c4adae3c3d02e4a8af924ecaf",
    "url": "/static/media/md-journal.e4ba680c.svg"
  },
  {
    "revision": "6d57f1193a70b0c4f3f7a5fa3596a529",
    "url": "/static/media/md-key.6d57f119.svg"
  },
  {
    "revision": "7afd336cdc35206b6a4eb9d08cf98cd0",
    "url": "/static/media/md-keypad.7afd336c.svg"
  },
  {
    "revision": "085b1d768f9eefbc7410a3d402635c6a",
    "url": "/static/media/md-laptop.085b1d76.svg"
  },
  {
    "revision": "8654cc464e229feb1d7da203b6719c15",
    "url": "/static/media/md-leaf.8654cc46.svg"
  },
  {
    "revision": "39fd3a56a36a253fe0b0611f8bc3b471",
    "url": "/static/media/md-link.39fd3a56.svg"
  },
  {
    "revision": "78dd32829ce6bd94f1f09f6f6d04761d",
    "url": "/static/media/md-list-box.78dd3282.svg"
  },
  {
    "revision": "250f9d1904c556a57d4d4b36dddb76ec",
    "url": "/static/media/md-list.250f9d19.svg"
  },
  {
    "revision": "b82309512533ee7e77f5306078022dba",
    "url": "/static/media/md-locate.b8230951.svg"
  },
  {
    "revision": "602bbf9869e9caadb39acd39f21cef12",
    "url": "/static/media/md-lock.602bbf98.svg"
  },
  {
    "revision": "44896c0a2c8a647ee03cfcbab8001329",
    "url": "/static/media/md-log-in.44896c0a.svg"
  },
  {
    "revision": "2deb7d54fb85859a6292f65c7b5e6631",
    "url": "/static/media/md-log-out.2deb7d54.svg"
  },
  {
    "revision": "a4e314445ebfde50049483f7e504ed9c",
    "url": "/static/media/md-magnet.a4e31444.svg"
  },
  {
    "revision": "0da036c25a7e5a08608770a9785a8f24",
    "url": "/static/media/md-mail-open.0da036c2.svg"
  },
  {
    "revision": "b20afe46b7c315e5c90e31ee36b9f7ad",
    "url": "/static/media/md-mail-unread.b20afe46.svg"
  },
  {
    "revision": "cdb6a2068b7747d27bed242e36714618",
    "url": "/static/media/md-mail.cdb6a206.svg"
  },
  {
    "revision": "6cb30eeebbbbaf62a80f825b04d685e8",
    "url": "/static/media/md-male.6cb30eee.svg"
  },
  {
    "revision": "b5efbf6073f7fd59fe369e6ad8111578",
    "url": "/static/media/md-man.b5efbf60.svg"
  },
  {
    "revision": "3cb1e3cfa740a32e46112941997d6824",
    "url": "/static/media/md-map.3cb1e3cf.svg"
  },
  {
    "revision": "9a281aab18f5a66cee5cc21098352b17",
    "url": "/static/media/md-medal.9a281aab.svg"
  },
  {
    "revision": "3a0b8f72d48b1a4de39b2bbcbf7cdb6f",
    "url": "/static/media/md-medical.3a0b8f72.svg"
  },
  {
    "revision": "8c82a5706f24721531ab50fbb92690e2",
    "url": "/static/media/md-medkit.8c82a570.svg"
  },
  {
    "revision": "f1694d823b0b26c982ab665bc7a96664",
    "url": "/static/media/md-megaphone.f1694d82.svg"
  },
  {
    "revision": "4e10f85b6eb5c93687bf7bdf0557e8e8",
    "url": "/static/media/md-menu.4e10f85b.svg"
  },
  {
    "revision": "befd36158252c12c0963b4e7bde02026",
    "url": "/static/media/md-mic-off.befd3615.svg"
  },
  {
    "revision": "8667f3589b67a1d9c3b1384bb343d19c",
    "url": "/static/media/md-mic.8667f358.svg"
  },
  {
    "revision": "cba83723c1980298dea9f6b18e30b54d",
    "url": "/static/media/md-microphone.cba83723.svg"
  },
  {
    "revision": "99ab2f960fdaacc76cd6e5ec837fcb41",
    "url": "/static/media/md-moon.99ab2f96.svg"
  },
  {
    "revision": "9c0bd80212ce673baae08790a484457e",
    "url": "/static/media/md-more.9c0bd802.svg"
  },
  {
    "revision": "994962c528c6d6a20c6b4bedecd7357a",
    "url": "/static/media/md-move.994962c5.svg"
  },
  {
    "revision": "acd6f29a8c515f6bd68d0b355e53e778",
    "url": "/static/media/md-musical-note.acd6f29a.svg"
  },
  {
    "revision": "c207ad354c533db6967e994959383f04",
    "url": "/static/media/md-musical-notes.c207ad35.svg"
  },
  {
    "revision": "21ea820749e9ba11c29b668601542df8",
    "url": "/static/media/md-navigate.21ea8207.svg"
  },
  {
    "revision": "fa53fc0ed0d74a8f4f67d8d29f7c9158",
    "url": "/static/media/md-notifications-off.fa53fc0e.svg"
  },
  {
    "revision": "8c92d157997b6c4b232adef93f659c96",
    "url": "/static/media/md-notifications-outline.8c92d157.svg"
  },
  {
    "revision": "bab1701f163c2ea5e87cad56cf7177c8",
    "url": "/static/media/md-notifications.bab1701f.svg"
  },
  {
    "revision": "486b196acea740952ae46b41428c42ea",
    "url": "/static/media/md-nuclear.486b196a.svg"
  },
  {
    "revision": "189ce36cae4104de7e93357cdf91c3b3",
    "url": "/static/media/md-nutrition.189ce36c.svg"
  },
  {
    "revision": "39dc2eb53fb4f2799135bc7b1e84cf89",
    "url": "/static/media/md-open.39dc2eb5.svg"
  },
  {
    "revision": "72fe8b50600191ea292df63511d16296",
    "url": "/static/media/md-options.72fe8b50.svg"
  },
  {
    "revision": "58d94b5d994e09c73dd9ed1b470f073b",
    "url": "/static/media/md-outlet.58d94b5d.svg"
  },
  {
    "revision": "d4ae298a1525b3ca4c0ebf02857b9097",
    "url": "/static/media/md-paper-plane.d4ae298a.svg"
  },
  {
    "revision": "9aa1466b4a90bd8abc04888b8c975856",
    "url": "/static/media/md-paper.9aa1466b.svg"
  },
  {
    "revision": "018889ccb5dcf8934437a718d9033eb4",
    "url": "/static/media/md-partly-sunny.018889cc.svg"
  },
  {
    "revision": "ef275f0a4ca69abd2cbdd4053adf8cff",
    "url": "/static/media/md-pause.ef275f0a.svg"
  },
  {
    "revision": "3fc1ee0933f6f0da0642eb5fa49ddb32",
    "url": "/static/media/md-paw.3fc1ee09.svg"
  },
  {
    "revision": "7e072eb3be5766c519fcf5f487c4df81",
    "url": "/static/media/md-people.7e072eb3.svg"
  },
  {
    "revision": "12ba58a7261e649cee363012ca72f38b",
    "url": "/static/media/md-person-add.12ba58a7.svg"
  },
  {
    "revision": "d5374614cae28ef5a18a80c2f29dd21f",
    "url": "/static/media/md-person.d5374614.svg"
  },
  {
    "revision": "dd0357e51b7ddb5313a7d59f643b67b7",
    "url": "/static/media/md-phone-landscape.dd0357e5.svg"
  },
  {
    "revision": "cc2526502c311a158e3d4dc4deb01bea",
    "url": "/static/media/md-phone-portrait.cc252650.svg"
  },
  {
    "revision": "5e68ad9b9afa50556b268469813f1dd7",
    "url": "/static/media/md-photos.5e68ad9b.svg"
  },
  {
    "revision": "f47cb3cb00439bfba31ccb15358ed5e6",
    "url": "/static/media/md-pie.f47cb3cb.svg"
  },
  {
    "revision": "a3f117f086ab9f1a07ae652911ac2645",
    "url": "/static/media/md-pin.a3f117f0.svg"
  },
  {
    "revision": "0e585f3302b15c7ad03f1aba24f52a57",
    "url": "/static/media/md-pint.0e585f33.svg"
  },
  {
    "revision": "f959f98fac52821339aafceb5ea2dd9e",
    "url": "/static/media/md-pizza.f959f98f.svg"
  },
  {
    "revision": "8dba5e773799386e44647231bf940855",
    "url": "/static/media/md-planet.8dba5e77.svg"
  },
  {
    "revision": "3c1d0b1ae213abad45b40e3c28250bab",
    "url": "/static/media/md-play-circle.3c1d0b1a.svg"
  },
  {
    "revision": "81c9de128ebdf12b70656caa19e0c592",
    "url": "/static/media/md-play.81c9de12.svg"
  },
  {
    "revision": "87a7b8d2e77e2cfb1c08483c11a0d039",
    "url": "/static/media/md-podium.87a7b8d2.svg"
  },
  {
    "revision": "2ab627e800c35f11c431b7fbf7a4f1c5",
    "url": "/static/media/md-power.2ab627e8.svg"
  },
  {
    "revision": "2db7c006142fba046fcabc6469010172",
    "url": "/static/media/md-pricetag.2db7c006.svg"
  },
  {
    "revision": "ae695e8754e64f15b5b6501ed06cd3af",
    "url": "/static/media/md-pricetags.ae695e87.svg"
  },
  {
    "revision": "3c09a2bb3e7dd4d277f41a2229fa8864",
    "url": "/static/media/md-print.3c09a2bb.svg"
  },
  {
    "revision": "70a5f9c1dbc6168d705323a78c94994b",
    "url": "/static/media/md-pulse.70a5f9c1.svg"
  },
  {
    "revision": "f2671f20f69bc0e4953aff636474b1d0",
    "url": "/static/media/md-qr-scanner.f2671f20.svg"
  },
  {
    "revision": "6127684735169e01eb287a5bff8e28e9",
    "url": "/static/media/md-quote.61276847.svg"
  },
  {
    "revision": "4b712f4fd564761197599e819a30c994",
    "url": "/static/media/md-radio-button-off.4b712f4f.svg"
  },
  {
    "revision": "25108f0173f1193b2b6325241aee7598",
    "url": "/static/media/md-radio-button-on.25108f01.svg"
  },
  {
    "revision": "f85bf3de30e985918c4353dab6858715",
    "url": "/static/media/md-radio.f85bf3de.svg"
  },
  {
    "revision": "2121352c4c61c828ab1238e59f3d9d65",
    "url": "/static/media/md-rainy.2121352c.svg"
  },
  {
    "revision": "6623a1303d029a386cb95ffeda60e064",
    "url": "/static/media/md-recording.6623a130.svg"
  },
  {
    "revision": "d18a7df958fb128a57fdc4794b6a0819",
    "url": "/static/media/md-redo.d18a7df9.svg"
  },
  {
    "revision": "bf1d0ba523921c7e852fb574b3b1d0d6",
    "url": "/static/media/md-refresh-circle.bf1d0ba5.svg"
  },
  {
    "revision": "8cde2f6b67a62e1ff8a583da745519f3",
    "url": "/static/media/md-refresh.8cde2f6b.svg"
  },
  {
    "revision": "18bdbaa32576c126f6c740a36e39b504",
    "url": "/static/media/md-remove-circle-outline.18bdbaa3.svg"
  },
  {
    "revision": "173207eec1045809681fa252ae1a47f9",
    "url": "/static/media/md-remove-circle.173207ee.svg"
  },
  {
    "revision": "5aaa411554c5dc87a29ccc9b442141eb",
    "url": "/static/media/md-remove.5aaa4115.svg"
  },
  {
    "revision": "8a05dea1647609a035e335d116c1c22a",
    "url": "/static/media/md-reorder.8a05dea1.svg"
  },
  {
    "revision": "2f28dffe698c2b64924d6444de65aca5",
    "url": "/static/media/md-repeat.2f28dffe.svg"
  },
  {
    "revision": "dc9eb61db7eced95c8ab9fcc0c8890b8",
    "url": "/static/media/md-resize.dc9eb61d.svg"
  },
  {
    "revision": "504a2e8ac0aa66edf3b551f1bdea9167",
    "url": "/static/media/md-restaurant.504a2e8a.svg"
  },
  {
    "revision": "34b30ae4b17c7fcd0ac79449c84dbcc2",
    "url": "/static/media/md-return-left.34b30ae4.svg"
  },
  {
    "revision": "a4b78bd3db6cc61c3d292aa3fb4a3ecd",
    "url": "/static/media/md-return-right.a4b78bd3.svg"
  },
  {
    "revision": "5f7a59556e40720d34d77c10dccaf643",
    "url": "/static/media/md-reverse-camera.5f7a5955.svg"
  },
  {
    "revision": "5a79fae9d21adcf0e1548ff1aae90f90",
    "url": "/static/media/md-rewind.5a79fae9.svg"
  },
  {
    "revision": "42633c14b274b7057a26423ee488c7cf",
    "url": "/static/media/md-ribbon.42633c14.svg"
  },
  {
    "revision": "bf5d2a060b052132ee4e12433d6fc769",
    "url": "/static/media/md-rocket.bf5d2a06.svg"
  },
  {
    "revision": "7476d50e3a2118a45e8f1f2b5a0b8c22",
    "url": "/static/media/md-rose.7476d50e.svg"
  },
  {
    "revision": "a457c526ff40e2b143db2177af0c4bd9",
    "url": "/static/media/md-sad.a457c526.svg"
  },
  {
    "revision": "f9c8c68be9811cd40e83705984819c84",
    "url": "/static/media/md-save.f9c8c68b.svg"
  },
  {
    "revision": "d3f10a7643a7b3f45f4a95be0993b617",
    "url": "/static/media/md-school.d3f10a76.svg"
  },
  {
    "revision": "ca1a8ecaf1fbb7d19f3649d04ffc3c53",
    "url": "/static/media/md-search.ca1a8eca.svg"
  },
  {
    "revision": "dd47517fd2e310661df1338e6b13cc4d",
    "url": "/static/media/md-send.dd47517f.svg"
  },
  {
    "revision": "4eabf90d7b4ab30a519eb2df23d45a2b",
    "url": "/static/media/md-settings.4eabf90d.svg"
  },
  {
    "revision": "aed8ca4138d09baa12e0334114d7d6bb",
    "url": "/static/media/md-share-alt.aed8ca41.svg"
  },
  {
    "revision": "98db64c449b712e0a6950dd40480e561",
    "url": "/static/media/md-share.98db64c4.svg"
  },
  {
    "revision": "0fa56aeefd58accd4eaf67057f0a47e5",
    "url": "/static/media/md-shirt.0fa56aee.svg"
  },
  {
    "revision": "3e2996492200df79a27f67f71e22d770",
    "url": "/static/media/md-shuffle.3e299649.svg"
  },
  {
    "revision": "51eb1462ac49b3cbe640ae4ca3f524fd",
    "url": "/static/media/md-skip-backward.51eb1462.svg"
  },
  {
    "revision": "2e5c16df5e8465b40f4ec298246a40bc",
    "url": "/static/media/md-skip-forward.2e5c16df.svg"
  },
  {
    "revision": "7f621bff285cee5caba673c580ae74d6",
    "url": "/static/media/md-snow.7f621bff.svg"
  },
  {
    "revision": "e976093c0b533ce5fe22dee79dfd3d49",
    "url": "/static/media/md-speedometer.e976093c.svg"
  },
  {
    "revision": "f08c45e628256769924877bb4e118ff1",
    "url": "/static/media/md-square-outline.f08c45e6.svg"
  },
  {
    "revision": "fa10cfed2a30917a1f61a430334a79ef",
    "url": "/static/media/md-square.fa10cfed.svg"
  },
  {
    "revision": "c45a1565c134b82bfd9ee15561880b39",
    "url": "/static/media/md-star-half.c45a1565.svg"
  },
  {
    "revision": "2c1d0c7136e5d886f301d10f5f90d803",
    "url": "/static/media/md-star-outline.2c1d0c71.svg"
  },
  {
    "revision": "c2138895d8cabaf6740f7bb04b57345c",
    "url": "/static/media/md-star.c2138895.svg"
  },
  {
    "revision": "77e760b406338e63fe7b3111eff4252a",
    "url": "/static/media/md-stats.77e760b4.svg"
  },
  {
    "revision": "d7f04ea50286daf7e78910f322b198cd",
    "url": "/static/media/md-stopwatch.d7f04ea5.svg"
  },
  {
    "revision": "265774e7957ac942233a210db53e7367",
    "url": "/static/media/md-subway.265774e7.svg"
  },
  {
    "revision": "6d8661c3ff92ca5e42cf00bb1371b6b6",
    "url": "/static/media/md-sunny.6d8661c3.svg"
  },
  {
    "revision": "b230d50fc48c30e8c5c0ae88d5d68334",
    "url": "/static/media/md-swap.b230d50f.svg"
  },
  {
    "revision": "74c01611ee7b57b178ef1ef0022c4d80",
    "url": "/static/media/md-switch.74c01611.svg"
  },
  {
    "revision": "a0fb5f7a8afad9a854377ce396a71b5b",
    "url": "/static/media/md-sync.a0fb5f7a.svg"
  },
  {
    "revision": "d6746961214fd6ecd6f602f78a305a60",
    "url": "/static/media/md-tablet-landscape.d6746961.svg"
  },
  {
    "revision": "10fa9fdb3a5afa0127f18eccc9c6c849",
    "url": "/static/media/md-tablet-portrait.10fa9fdb.svg"
  },
  {
    "revision": "43ef4a3d87551796064c924b2e25fd85",
    "url": "/static/media/md-tennisball.43ef4a3d.svg"
  },
  {
    "revision": "73428a44bba9bcc4476445067103bcb1",
    "url": "/static/media/md-text.73428a44.svg"
  },
  {
    "revision": "da346ce6fb8c2767089c357b4d618465",
    "url": "/static/media/md-thermometer.da346ce6.svg"
  },
  {
    "revision": "6a2f8e0846eba7a8dc7008a05fc4188e",
    "url": "/static/media/md-thumbs-down.6a2f8e08.svg"
  },
  {
    "revision": "fc44d85e149bb430f9a053f2478ca6ca",
    "url": "/static/media/md-thumbs-up.fc44d85e.svg"
  },
  {
    "revision": "049188c8dbcda95b970beaf14a5b0c04",
    "url": "/static/media/md-thunderstorm.049188c8.svg"
  },
  {
    "revision": "130e75e7f13f66b72ec2acde8378b661",
    "url": "/static/media/md-time.130e75e7.svg"
  },
  {
    "revision": "6d7bdec4fce3c09732d09084b7018f7b",
    "url": "/static/media/md-timer.6d7bdec4.svg"
  },
  {
    "revision": "411e8f5a83e042b48b9fea6fe9cecdf4",
    "url": "/static/media/md-today.411e8f5a.svg"
  },
  {
    "revision": "7ca851cda71bfd47c22e3d549ab6db1c",
    "url": "/static/media/md-train.7ca851cd.svg"
  },
  {
    "revision": "25a075f44e5d0fb6e7d51094e2582d5a",
    "url": "/static/media/md-transgender.25a075f4.svg"
  },
  {
    "revision": "2141e00a09054bbc752f1755168947b7",
    "url": "/static/media/md-trash.2141e00a.svg"
  },
  {
    "revision": "65426337171d67608c5ef84b1a4895cc",
    "url": "/static/media/md-trending-down.65426337.svg"
  },
  {
    "revision": "8ccacbe00be9329b71125e08fe6e0b3a",
    "url": "/static/media/md-trending-up.8ccacbe0.svg"
  },
  {
    "revision": "2e69cc06691464d4559570b03ad85dba",
    "url": "/static/media/md-trophy.2e69cc06.svg"
  },
  {
    "revision": "08c72b39fafdd76db66744f7ba7a519c",
    "url": "/static/media/md-tv.08c72b39.svg"
  },
  {
    "revision": "c153669ba06aa9b2bf562e6f957ab14f",
    "url": "/static/media/md-umbrella.c153669b.svg"
  },
  {
    "revision": "e2e835621053ea7d5db711d147a76694",
    "url": "/static/media/md-undo.e2e83562.svg"
  },
  {
    "revision": "93c2a9882b1d58aea1277ff08f04c240",
    "url": "/static/media/md-unlock.93c2a988.svg"
  },
  {
    "revision": "deb3e4aa3ae4b1de2f44ed6603847d06",
    "url": "/static/media/md-videocam.deb3e4aa.svg"
  },
  {
    "revision": "e6445464e4e55d0aa413577fd8e1bdf9",
    "url": "/static/media/md-volume-high.e6445464.svg"
  },
  {
    "revision": "95f637872ba75897a861e40fe3bcccb9",
    "url": "/static/media/md-volume-low.95f63787.svg"
  },
  {
    "revision": "e7422c3fb69dd1bb3f461839aeb9e0a9",
    "url": "/static/media/md-volume-mute.e7422c3f.svg"
  },
  {
    "revision": "3f8924a4a165adf6ad98b6a22e694f0d",
    "url": "/static/media/md-volume-off.3f8924a4.svg"
  },
  {
    "revision": "629f0c95d3c4e64a530c6bc4a3435f6a",
    "url": "/static/media/md-walk.629f0c95.svg"
  },
  {
    "revision": "466600041a25718d1de54ab79b3925a9",
    "url": "/static/media/md-wallet.46660004.svg"
  },
  {
    "revision": "2f8f481c42b286869477d302933f9090",
    "url": "/static/media/md-warning.2f8f481c.svg"
  },
  {
    "revision": "cd7f70387cbf4226a647e957f45d9009",
    "url": "/static/media/md-watch.cd7f7038.svg"
  },
  {
    "revision": "cd816137fc19ab71f63f159670f380af",
    "url": "/static/media/md-water.cd816137.svg"
  },
  {
    "revision": "f7019f64fec177143a92780f2611b3e4",
    "url": "/static/media/md-wifi.f7019f64.svg"
  },
  {
    "revision": "1d82d46b9d9c87fabd5f0b7ba385b5d5",
    "url": "/static/media/md-wine.1d82d46b.svg"
  },
  {
    "revision": "05ce5b2ca1e24f9c2f3e3104e08b1a75",
    "url": "/static/media/md-woman.05ce5b2c.svg"
  }
]);